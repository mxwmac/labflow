// 共有状態と小さな UI ヘルパー
export const S = {
  cfg: null,        // /api/config
  user: null,
  settings: {},
  phases: [],
  tasks: [],
  meetings: [],
  progress: [],
  actions: null,
  usage: { used: 0, limit: 0 },
  today: '',
};

// 状態変化の通知（各カードが必要なものだけ購読する）
const bus = new EventTarget();
export const on = (name, fn) => bus.addEventListener(name, () => fn());
export const emit = (...names) => names.forEach(n => bus.dispatchEvent(new Event(n)));

export const $ = (s, root = document) => root.querySelector(s);
export const $$ = (s, root = document) => [...root.querySelectorAll(s)];
export const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export const WD = ['日', '月', '火', '水', '木', '金', '土'];
export const pad = n => String(n).padStart(2, '0');
export const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
export const ymdLocal = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const md = ymd => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ymd || '')) return ymd || '';
  const d = new Date(ymd + 'T00:00:00');
  return `${d.getMonth() + 1}/${d.getDate()}(${WD[d.getDay()]})`;
};
export const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);

export const SEV = { high: ['high', '要対応'], mid: ['warn', '重要'], low: ['mute', '参考'] };
export const PRI = { high: '高', mid: '中', low: '低' };

export function msg(sel, html, kind = 'load') {
  const el = typeof sel === 'string' ? $(sel) : sel;
  el.innerHTML = html ? `<div class="${kind}">${html}</div>` : '';
}
export const busy = (sel, text) => msg(sel, `<span class="spin"></span>${esc(text)}`);
export const err = (sel, text) => msg(sel, esc(text), 'err');

export function setStatus(sel, text, kind) {
  const el = $(sel);
  el.className = 'chip ' + (kind || 'mute');
  el.innerHTML = `<span class="dot"></span>${esc(text)}`;
}

/** 画面下に数秒出る通知。action: {label, href} or {label, fn} */
export function toast(text, { kind = 'ok', action, ms = 4200 } = {}) {
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.innerHTML = `<span>${esc(text)}</span>`;
  if (action?.href) {
    const a = document.createElement('a');
    a.href = action.href; a.target = '_blank'; a.rel = 'noopener'; a.textContent = action.label;
    el.append(a);
  } else if (action?.fn) {
    const b = document.createElement('button');
    b.textContent = action.label;
    b.onclick = () => { action.fn(); el.remove(); };
    el.append(b);
  }
  $('#toasts').append(el);
  setTimeout(() => el.remove(), ms);
}

/** 汎用の確認ダイアログ */
export function confirmDialog({ title, body, ok = 'OK', danger = false }) {
  const d = $('#dlg-confirm');
  $('#cf-h').textContent = title;
  $('#cf-body').textContent = body || '';
  const b = $('#cf-ok');
  b.textContent = ok;
  b.className = 'neu btn ' + (danger ? 'danger' : 'primary');
  d.returnValue = '';
  d.showModal();
  return new Promise(res => d.addEventListener('close', () => res(d.returnValue === 'ok'), { once: true }));
}

/** セグメントボタン（aria-pressed）の選択値 */
export function segValue(root, attr) {
  return $('[aria-pressed="true"]', root)?.dataset[attr];
}
export function bindSeg(root, attr, onChange) {
  root.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || !root.contains(b)) return;
    root.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    onChange?.(b.dataset[attr]);
  });
}
export function setSeg(root, attr, value) {
  root.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', String(x.dataset[attr] === value)));
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export function store(key, val) {
  try {
    if (val === undefined) return localStorage.getItem(key);
    localStorage.setItem(key, val);
  } catch (e) { return null; }
}
