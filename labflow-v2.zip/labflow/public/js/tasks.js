// タスク: 追加・完了・編集・削除、期限と優先度、絞り込み
import { S, $, esc, on, emit, md, toast, PRI, bindSeg, setSeg, store, daysBetween } from './state.js';
import { post, patch, del } from './api.js';
import { openEventDialog } from './calendar.js';

let filter = store('labflow.taskFilter') || 'open';
const PO = { high: 0, mid: 1, low: 2 };
const isLate = t => !t.done && t.due && t.due < S.today;

function sorted() {
  return [...S.tasks].sort((a, b) =>
    (a.done - b.done) ||
    (isLate(b) - isLate(a)) ||
    ((a.due || '9999') < (b.due || '9999') ? -1 : (a.due || '9999') > (b.due || '9999') ? 1 : 0) ||
    ((PO[a.priority] ?? 1) - (PO[b.priority] ?? 1)) ||
    String(a.createdAt).localeCompare(String(b.createdAt)));
}

function dueLabel(t) {
  if (!t.due) return t.dueText ? `⏱ ${esc(t.dueText)}` : '';
  const d = daysBetween(S.today, t.due);
  if (t.done) return `⏱ ${md(t.due)}`;
  if (d < 0) return `<small class="late">⚠ ${-d}日超過（${md(t.due)}）</small>`;
  if (d === 0) return `<small class="late">⏱ 今日まで</small>`;
  return `⏱ ${md(t.due)}${d <= 3 ? `（あと${d}日）` : ''}`;
}

export function renderTasks() {
  const done = S.tasks.filter(t => t.done).length;
  const late = S.tasks.filter(isLate).length;
  $('#task-count').innerHTML = `${done} / ${S.tasks.length} 完了${late ? ` ・ <span style="color:var(--high);font-weight:700">期限切れ ${late}</span>` : ''}`;
  const list = sorted().filter(t => (filter === 'open' ? !t.done : filter === 'late' ? isLate(t) : true));
  $('#task-list').innerHTML = list.map(t => `
    <li class="task ${t.done ? 'done' : ''} ${isLate(t) ? 'late' : ''}" data-id="${esc(t.id)}">
      <button class="cbx" data-act="toggle" role="checkbox" aria-checked="${t.done}" aria-label="${esc(t.title)} を${t.done ? '未完了に戻す' : '完了にする'}">✔</button>
      <span class="pri ${esc(t.priority || 'mid')}" title="優先度: ${PRI[t.priority] || '中'}"></span>
      <div class="t-body" data-act="edit" title="クリックで編集">
        <div class="t-title">${esc(t.title)}</div>
        <div class="t-meta">
          ${t.tag ? `<span class="chip mute sm">${esc(t.tag)}</span>` : ''}
          ${(t.source?.type === 'mtg' || t.source?.type === 'point') && t.tag !== 'MTG' ? '<span class="chip sm">MTG</span>' : t.source?.type === 'suggest' && t.tag !== '提案' ? '<span class="chip sm">提案</span>' : ''}
          <small>${dueLabel(t)}</small>
          ${t.memo ? '<small>📝</small>' : ''}
        </div>
      </div>
      <button class="del" data-act="del" aria-label="${esc(t.title)} を削除">✕</button>
    </li>`).join('') || `<div class="empty">${filter === 'late' ? '期限切れのタスクはありません 🎉' : filter === 'open' ? '未完了のタスクはありません' : 'タスクはありません'}</div>`;
}

export async function addTask(title, { tag = '', due = '', dueText = '', priority = 'mid', source } = {}) {
  title = (title || '').trim();
  if (!title) return null;
  const isDate = /^\d{4}-\d{2}-\d{2}$/.test(due);
  try {
    const t = await post('/tasks', { title, tag, due: isDate ? due : '', dueText: isDate ? '' : (dueText || due || ''), priority, source });
    S.tasks.push(t);
    emit('tasks');
    return t;
  } catch (e) {
    toast(e.message, { kind: 'err' });
    return null;
  }
}

async function update(id, body) {
  const t = await patch('/tasks/' + encodeURIComponent(id), body);
  S.tasks = S.tasks.map(x => (x.id === id ? t : x));
  emit('tasks');
  return t;
}

let editing = null;
function openEdit(t) {
  editing = t;
  $('#tk-title').value = t.title;
  $('#tk-due').value = t.due || '';
  $('#tk-pri').value = t.priority || 'mid';
  $('#tk-tag').value = t.tag || '';
  $('#tk-memo').value = t.memo || '';
  const m = t.source?.meetingId && S.meetings.find(x => x.id === t.source.meetingId);
  $('#tk-src').textContent = [
    t.dueText ? `元の期限表記: ${t.dueText}` : '',
    m ? `出典: ${md(m.date)} のMTG「${m.title}」` : t.source?.type === 'suggest' ? '出典: 次の一手の提案' : '',
  ].filter(Boolean).join(' ／ ');
  $('#dlg-task').returnValue = '';
  $('#dlg-task').showModal();
}

export function initTasks() {
  setSeg($('#task-filter'), 'f', filter);
  bindSeg($('#task-filter'), 'f', v => { filter = v; store('labflow.taskFilter', v); renderTasks(); });

  $('#task-list').addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = b.closest('.task').dataset.id;
    const t = S.tasks.find(x => x.id === id); if (!t) return;
    try {
      if (b.dataset.act === 'toggle') {
        await update(id, { done: !t.done });
        if (!t.done) toast('完了にしました', { action: { label: '元に戻す', fn: () => update(id, { done: false }) } });
      } else if (b.dataset.act === 'del') {
        await del('/tasks/' + encodeURIComponent(id));
        S.tasks = S.tasks.filter(x => x.id !== id);
        emit('tasks');
        toast('削除しました', {
          action: { label: '元に戻す', fn: () => addTask(t.title, { tag: t.tag, due: t.due, dueText: t.dueText, priority: t.priority, source: t.source }) },
        });
      } else if (b.dataset.act === 'edit') openEdit(t);
    } catch (er) { toast(er.message, { kind: 'err' }); }
  });

  const add = async () => {
    const t = await addTask($('#task-input').value, { due: $('#task-due').value, priority: $('#task-pri').value });
    if (t) { $('#task-input').value = ''; $('#task-due').value = ''; $('#task-pri').value = 'mid'; }
  };
  $('#task-add').onclick = add;
  $('#task-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); add(); } });

  $('#dlg-task').addEventListener('close', async () => {
    if ($('#dlg-task').returnValue !== 'save' || !editing) return;
    try {
      await update(editing.id, {
        title: $('#tk-title').value, due: $('#tk-due').value, priority: $('#tk-pri').value,
        tag: $('#tk-tag').value, memo: $('#tk-memo').value, ...($('#tk-due').value ? { dueText: '' } : {}),
      });
      toast('タスクを更新しました');
    } catch (er) { toast(er.message, { kind: 'err' }); }
  });
  $('#tk-cal').onclick = () => {
    const t = editing;
    $('#dlg-task').close();
    openEventDialog({ kind: 'focus', title: `作業: ${t.title}`, desc: t.memo || '' });
  };
  on('tasks', renderTasks);
}
