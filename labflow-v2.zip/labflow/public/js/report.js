// 報告書（週報・ゼミ進捗報告・相談依頼メール）の下書き生成
import { S, $, esc, emit, busy, msg, toast, bindSeg, segValue } from './state.js';
import { get, post } from './api.js';
import { getFreeSlots } from './calendar.js';

let history = [];

async function loadHistory() {
  try {
    history = await get('/reports');
    $('#rp-hist').innerHTML = '<option value="">過去の報告書…</option>' +
      history.map((r, i) => `<option value="${i}">${esc(r.title)}（${new Date(r.createdAt).toLocaleString('ja-JP', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}）</option>`).join('');
  } catch (e) { /* 一覧が取れなくても生成はできる */ }
}

function syncMail() {
  $('#rp-mail').hidden = segValue($('#rp-kind'), 'k') !== 'email';
}

async function generate() {
  const btn = $('#rp-gen');
  btn.disabled = true;
  busy('#rp-msg', 'Gemini が下書きを作成中…');
  try {
    const r = await post('/reports', { kind: segValue($('#rp-kind'), 'k'), days: +$('#rp-days').value, freeSlots: getFreeSlots() });
    $('#rp-out').value = r.report.markdown;
    if (r.usage) { S.usage = r.usage; emit('usage'); }
    msg('#rp-msg', r.notice ? esc('Gemini を呼び出せなかったため、テンプレートで作成しました: ' + r.notice)
      : r.report.fallback ? 'デモモードのためテンプレートで作成しました。' : '', r.notice ? 'err' : 'info');
    loadHistory();
  } catch (e) {
    msg('#rp-msg', esc(e.message), 'err');
  } finally {
    btn.disabled = false;
  }
}

export function openReport() {
  syncMail();
  loadHistory();
  $('#dlg-report').showModal();
}

export function initReport() {
  $('#btn-report').onclick = openReport;
  $('#rp-close').onclick = () => $('#dlg-report').close();
  bindSeg($('#rp-kind'), 'k', syncMail);
  $('#rp-gen').onclick = generate;
  $('#rp-copy').onclick = async () => {
    try { await navigator.clipboard.writeText($('#rp-out').value); toast('コピーしました'); }
    catch (e) { $('#rp-out').select(); document.execCommand('copy'); toast('コピーしました'); }
  };
  $('#rp-dl').onclick = () => {
    const kind = segValue($('#rp-kind'), 'k');
    const blob = new Blob([$('#rp-out').value], { type: 'text/markdown;charset=utf-8' });
    const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `labflow-${kind}-${S.today}.md` });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  $('#rp-mail').onclick = () => {
    const text = $('#rp-out').value;
    const m = /^件名[:：]\s*(.+)$/m.exec(text);
    const body = m ? text.replace(m[0], '').trim() : text;
    const to = /@/.test(S.settings.calId) ? S.settings.calId : '';
    location.href = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(m?.[1] || '研究のご相談')}&body=${encodeURIComponent(body)}`;
  };
  $('#rp-hist').onchange = e => {
    const r = history[+e.target.value];
    if (r) { $('#rp-out').value = r.markdown; msg('#rp-msg', esc(`「${r.title}」を表示しています`), 'info'); }
    e.target.value = '';
  };
}
