// 設定ダイアログ・全データ削除
import { S, $, esc, emit, toast, store } from './state.js';
import { patch, post } from './api.js';

const hours = (from, to) => Array.from({ length: to - from + 1 }, (_, i) => from + i).map(h => `<option value="${h}">${h}:00</option>`).join('');

export function applyTheme() {
  document.documentElement.dataset.theme = S.settings.theme || 'light';
  store('labflow.theme', S.settings.theme || 'light');
}

export function openSettings() {
  const s = S.settings;
  $('#in-model').innerHTML = S.cfg.models.map(m => `<option value="${esc(m)}">${esc(m)}${m === S.cfg.defaultModel ? '（推奨）' : ''}</option>`).join('');
  $('#in-model').value = s.model;
  $('#in-calid').value = s.calId || '';
  $('#in-topic').value = s.topic || '';
  $('#in-phases').value = S.phases.map(p => p.name).join('\n');
  $('#in-ws').innerHTML = hours(6, 22); $('#in-ws').value = String(s.workStart);
  $('#in-we').innerHTML = hours(7, 23); $('#in-we').value = String(s.workEnd);
  $('#in-min').value = String(s.minSlot);
  $('#in-mine').checked = !!s.includeMine;
  $('#in-demo').checked = !!s.demoCal;
  const ai = { vertex: 'Vertex AI（Google Cloud）', apikey: 'Gemini API', mock: 'デモ（AIを呼び出さない）' }[S.cfg.aiMode] || S.cfg.aiMode;
  $('#set-info').innerHTML = `ログイン中: <b>${esc(S.user.isAnonymous ? 'ゲスト' : S.user.email || S.user.name)}</b> ／ AI: ${esc(ai)} ／ 本日の AI 利用 ${S.usage.used} / ${S.usage.limit} 回<br>
    メモの画像・PDFは解析後に破棄され、サーバーには保存されません。Googleカレンダーのアクセス権はこのブラウザのメモリ上だけで使います。`;
  $('#dlg-settings').returnValue = '';
  $('#dlg-settings').showModal();
}

async function saveSettings() {
  const body = {
    model: $('#in-model').value,
    calId: $('#in-calid').value.trim(),
    topic: $('#in-topic').value.trim(),
    phaseNames: $('#in-phases').value.split('\n').map(x => x.trim()).filter(Boolean),
    workStart: +$('#in-ws').value,
    workEnd: +$('#in-we').value,
    minSlot: +$('#in-min').value,
    includeMine: $('#in-mine').checked,
    demoCal: $('#in-demo').checked,
  };
  try {
    const r = await patch('/settings', body);
    const calChanged = r.settings.calId !== S.settings.calId;
    S.settings = r.settings;
    if (r.phases) S.phases = r.phases;
    emit('settings', 'phases', 'usage');
    toast(calChanged && r.settings.calId ? '保存しました。カレンダーを読み直します' : '設定を保存しました');
  } catch (e) { toast(e.message, { kind: 'err' }); }
}

export function initSettings() {
  $('#btn-settings').onclick = openSettings;
  $('#dlg-settings').addEventListener('close', () => { if ($('#dlg-settings').returnValue === 'save') saveSettings(); });
  $('#btn-theme').onclick = async () => {
    S.settings.theme = S.settings.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    try { await patch('/settings', { theme: S.settings.theme }); } catch (e) { /* 表示だけ切り替われば十分 */ }
  };
  // 全データ削除: 設定ダイアログを閉じてから確認ダイアログを開く（returnValue が save でないので設定は保存されない）
  $('#btn-reset').onclick = () => { $('#dlg-settings').close(); $('#dlg-reset').showModal(); };
  $('#reset-cancel').onclick = () => $('#dlg-reset').close();
  const reset = async mode => {
    $('#reset-empty').disabled = $('#reset-sample').disabled = true;
    try {
      await post('/reset', { mode });
      location.reload();
    } catch (e) {
      toast(e.message, { kind: 'err' });
      $('#reset-empty').disabled = $('#reset-sample').disabled = false;
    }
  };
  $('#reset-empty').onclick = () => reset('empty');
  $('#reset-sample').onclick = () => reset('sample');
}
