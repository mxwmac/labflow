// LabFlow — 起動処理
import { S, $, esc, on, setStatus, toast } from './state.js';
import { get, setAuth } from './api.js';
import { initAuth, getIdToken, logout, linkGoogle, showLogin } from './auth.js';
import { initProgress, renderProgress } from './progress.js';
import { initTasks, renderTasks } from './tasks.js';
import { initCalendar, renderWeek, revokeCalendar } from './calendar.js';
import { initScan } from './scan.js';
import { initMeeting, renderMeetings } from './meeting.js';
import { initNext, renderNext } from './next.js';
import { initReport } from './report.js';
import { initSettings, applyTheme } from './settings.js';

let inited = false;

function renderStatus() {
  const mock = S.cfg.aiMode === 'mock';
  setStatus('#st-ai', mock ? 'AI: デモ' : `${S.settings.model} ・ ${S.usage.used}/${S.usage.limit}`, mock ? 'mute' : S.usage.used >= S.usage.limit ? 'high' : 'ok');
  $('#st-ai').title = mock ? 'AI_MODE=mock のため固定のサンプル応答を返します' : '本日の AI 利用回数 / 上限';
}

function renderUser() {
  const u = S.user;
  const name = u.isAnonymous ? 'ゲスト' : u.name || u.email || 'ユーザー';
  $('#user-name').textContent = name;
  const av = $('#user-avatar');
  if (u.picture) { av.style.backgroundImage = `url("${u.picture.replace(/"/g, '')}")`; av.textContent = ''; }
  else { av.style.backgroundImage = ''; av.textContent = name.slice(0, 1); }
  $('#menu-name').textContent = name;
  $('#menu-email').textContent = u.isAnonymous ? '（データはこのブラウザのゲストアカウントに保存）' : u.email || '';
  const guest = u.isAnonymous && S.cfg.authMode !== 'dev';
  $('#btn-link').hidden = !guest;
  $('#guest-banner').hidden = !guest;
  $('#btn-logout').hidden = S.cfg.authMode === 'dev';
}

function bindChrome() {
  const menu = $('#user-menu'), btn = $('#btn-user');
  const close = () => { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); };
  btn.onclick = e => { e.stopPropagation(); menu.hidden = !menu.hidden; btn.setAttribute('aria-expanded', String(!menu.hidden)); };
  document.addEventListener('click', e => { if (!menu.contains(e.target)) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  $('#btn-logout').onclick = async () => { close(); revokeCalendar(); await logout(); };
  const link = () => { close(); linkGoogle(() => loadApp()); };
  $('#btn-link').onclick = link;
  $('#btn-link-2').onclick = link;
}

async function loadApp() {
  let b;
  try {
    b = await get('/bootstrap');
  } catch (e) {
    showLogin();
    $('#login-msg').innerHTML = `<div class="err">${esc(e.message)}</div>`;
    return;
  }
  Object.assign(S, {
    user: b.user, settings: b.settings, phases: b.phases, tasks: b.tasks, meetings: b.meetings,
    progress: b.progress, actions: b.actions, usage: b.usage, today: b.today,
  });
  applyTheme();
  if (!inited) {
    inited = true;
    bindChrome();
    initProgress(); initTasks(); initCalendar(); initScan(); initMeeting(); initNext(); initReport(); initSettings();
    on('usage', renderStatus);
    on('settings', renderStatus);
  }
  $('#boot').hidden = true;
  $('#login').hidden = true;
  $('#app').hidden = false;
  renderUser(); renderStatus();
  renderProgress(); renderTasks(); renderMeetings(); renderNext();
  renderWeek();
  if (S.cfg.aiMode === 'mock') toast('デモモード（AI_MODE=mock）で動作中です。解析・提案は固定のサンプルを返します', { kind: 'warn', ms: 6000 });
}

async function boot() {
  try {
    S.cfg = await get('/config');
  } catch (e) {
    $('#boot').innerHTML = `<div class="err">サーバーに接続できませんでした: ${esc(e.message)}</div>`;
    return;
  }
  setAuth(getIdToken, () => toast('ログインの有効期限が切れました。ページを再読み込みしてください', { kind: 'err', ms: 8000 }));
  try {
    await initAuth({ onSignedIn: loadApp, onSignedOut: () => location.reload() });
  } catch (e) {
    showLogin();
    $('#login-msg').innerHTML = `<div class="err">ログイン機能を読み込めませんでした: ${esc(e.message)}</div>`;
  }
}

boot();
