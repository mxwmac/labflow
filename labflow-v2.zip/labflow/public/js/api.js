// サーバー API 呼び出し。Firebase の ID トークンを Authorization ヘッダーに付ける
let tokenFn = async () => null;
let onUnauthorized = () => {};
export function setAuth(fn, unauthorized) {
  tokenFn = fn;
  onUnauthorized = unauthorized || onUnauthorized;
}

export async function api(method, path, body) {
  const headers = { Accept: 'application/json' };
  const token = await tokenFn();
  if (token) headers.Authorization = 'Bearer ' + token;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  let r;
  try {
    r = await fetch('/api' + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (e) {
    throw new Error('サーバーに接続できませんでした。ネットワークを確認してください');
  }
  if (r.status === 204) return null;
  let data = null;
  try { data = await r.json(); } catch (e) { /* 空 or HTML */ }
  if (!r.ok) {
    if (r.status === 401) onUnauthorized();
    const e = new Error(data?.error?.message || `エラーが発生しました（${r.status}）`);
    e.status = r.status;
    e.code = data?.error?.code;
    throw e;
  }
  return data;
}
export const get = p => api('GET', p);
export const post = (p, b = {}) => api('POST', p, b);
export const put = (p, b) => api('PUT', p, b);
export const patch = (p, b) => api('PATCH', p, b);
export const del = p => api('DELETE', p);
