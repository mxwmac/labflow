// MTG メモの取り込み（画像は縮小して送る / PDF はそのまま）と Gemini 解析の呼び出し
import { S, $, esc, emit, msg, busy, err, toast, ymdLocal } from './state.js';
import { post } from './api.js';
import { selectMeeting } from './meeting.js';

let files = []; // {name, mime, data(base64), url?, bytes}
const MAX_SIDE = 2048;

function readAsDataURL(f) {
  return new Promise((ok, ng) => {
    const rd = new FileReader();
    rd.onload = () => ok(rd.result);
    rd.onerror = () => ng(rd.error);
    rd.readAsDataURL(f);
  });
}

/** 長辺 2048px の JPEG に縮小（文字の判読に十分で、転送量を 1/5 程度にできる） */
async function shrink(f) {
  try {
    const bmp = await createImageBitmap(f, { imageOrientation: 'from-image' });
    const k = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
    if (k === 1 && f.size < 1.5e6 && f.type !== 'image/heic' && f.type !== 'image/heif') { bmp.close?.(); return null; }
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    g.drawImage(bmp, 0, 0, c.width, c.height);
    bmp.close?.();
    return c.toDataURL('image/jpeg', 0.85);
  } catch (e) {
    return null; // デコードできない形式（一部ブラウザの HEIC など）は元のまま送る
  }
}

async function intake(list) {
  const arr = [...list];
  const bad = arr.filter(f => !(f.type.startsWith('image/') || f.type === 'application/pdf'));
  if (bad.length) toast(`画像・PDF以外は追加できません: ${bad.map(f => f.name).join(', ')}`, { kind: 'warn' });
  for (const f of arr.filter(f => !bad.includes(f))) {
    try {
      if (f.type === 'application/pdf') {
        const url = await readAsDataURL(f);
        files.push({ name: f.name, mime: 'application/pdf', data: url.split(',')[1], bytes: f.size });
      } else {
        const small = await shrink(f);
        const url = small || (await readAsDataURL(f));
        const mime = small ? 'image/jpeg' : f.type || 'image/jpeg';
        const data = url.split(',')[1];
        files.push({ name: f.name, mime, data, url, bytes: Math.floor((data.length * 3) / 4) });
      }
    } catch (e) {
      toast(`${f.name} を読み込めませんでした`, { kind: 'err' });
    }
  }
  renderThumbs();
}

function renderThumbs() {
  const total = files.reduce((a, f) => a + f.bytes, 0);
  const max = (S.cfg.maxUploadMB || 18) * 1024 * 1024;
  $('#thumbs').innerHTML = files.map((f, i) => f.mime === 'application/pdf'
    ? `<div class="thumb pdf" title="${esc(f.name)}"><div><b>📄</b>${esc(f.name.slice(0, 18))}</div><button data-i="${i}" aria-label="${esc(f.name)} を外す">✕</button></div>`
    : `<div class="thumb"><img src="${f.url}" alt="${esc(f.name)}"><button data-i="${i}" aria-label="${esc(f.name)} を外す">✕</button></div>`).join('')
    + (files.length ? `<span class="size-note" style="${total > max ? 'color:var(--high);font-weight:700' : ''}">${files.length}件 / ${(total / 1048576).toFixed(1)}MB（上限 ${S.cfg.maxUploadMB}MB）</span>` : '');
}

async function analyze() {
  if (!files.length) { msg('#scan-msg', '先にメモの画像かPDFを追加してください。'); return; }
  const btn = $('#analyze');
  btn.disabled = true;
  busy('#scan-msg', `Gemini が ${files.length} 件のメモを読み取り中…（30秒ほどかかることがあります）`);
  try {
    const r = await post('/meetings/analyze', {
      files: files.map(({ name, mime, data }) => ({ name, mime, data })),
      date: $('#scan-date').value || '',
    });
    S.meetings.unshift(r.meeting);
    S.meetings.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    if (r.usage) S.usage = r.usage;
    files = []; renderThumbs();
    msg('#scan-msg', '');
    emit('meetings', 'usage');
    selectMeeting(r.meeting.id, { scroll: true });
    const n = (r.meeting.unclear || []).length;
    toast(n ? `解析しました。読み取りに自信がない箇所が ${n} 件あります。確認してください` : '解析しました', { kind: n ? 'warn' : 'ok', ms: 6000 });
  } catch (e) {
    err('#scan-msg', e.message);
  } finally {
    btn.disabled = false;
  }
}

export function initScan() {
  const drop = $('#drop'), fileIn = $('#file');
  $('#scan-date').value = ymdLocal();
  drop.onclick = () => fileIn.click();
  drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileIn.click(); } };
  ['dragover', 'dragenter'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => intake(e.dataTransfer.files));
  fileIn.onchange = () => { intake(fileIn.files); fileIn.value = ''; };
  // クリップボードからの貼り付け（スクリーンショットなど）
  document.addEventListener('paste', e => {
    if (e.target.closest('input,textarea,[contenteditable]')) return;
    const imgs = [...(e.clipboardData?.files || [])].filter(f => f.type.startsWith('image/'));
    if (imgs.length) { intake(imgs); toast('貼り付けた画像を追加しました'); }
  });
  $('#thumbs').onclick = e => { const b = e.target.closest('button'); if (!b) return; files.splice(+b.dataset.i, 1); renderThumbs(); };
  $('#analyze').onclick = analyze;
}
