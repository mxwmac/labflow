// MTGノート（解析結果の表示・要確認の解消・編集）、未対応の指摘、MTG履歴
import { S, $, esc, on, emit, md, SEV, toast, confirmDialog, debounce } from './state.js';
import { put, patch, del } from './api.js';
import { addTask } from './tasks.js';

let sel = null;        // 表示中の MTG id
let editing = null;    // 編集中の下書き（null なら閲覧モード）
let showAllPoints = false;
let q = '';

const cur = () => S.meetings.find(m => m.id === sel) || S.meetings[0] || null;
const openUnclear = m => (m.unclear || []).filter(u => !u.resolved);
const CONF = { high: ['ok', '読み取り良好'], mid: ['warn', '一部不明瞭'], low: ['high', '判読困難'] };
const uncChip = (sec, i) => `<button class="chip unc sm" data-act="unc-ok" data-sec="${sec}" data-i="${i}" title="確認できたら押してください">要確認</button>`;
const taskOf = refId => S.tasks.find(t => t.source?.refId === refId);

export function selectMeeting(id, { scroll = false } = {}) {
  sel = id; editing = null;
  renderNote(); renderHistory();
  if (scroll) $('#note-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================================
 * 閲覧モード
 * ========================================================== */
function renderNote() {
  const m = cur();
  $('#note-tools').hidden = !m;
  if (!m) {
    $('#note-sub').textContent = 'まだ解析していません';
    $('#note').innerHTML = '<div class="empty">メモ画像を解析すると、ここに議論の流れと指摘が並びます。</div>';
    return;
  }
  sel = m.id;
  $('#note-sub').textContent = `${md(m.date)} ／ ${m.title}`;
  $('#note-edit').textContent = editing ? '閲覧に戻る' : '✏️ 編集';
  if (editing) { renderEditor(); return; }

  const unc = openUnclear(m);
  const [cc, cl] = CONF[m.confidence] || CONF.mid;
  $('#note').innerHTML = `
    <div class="meta-chips">
      <span class="chip ${cc} sm">${cl}</span>
      ${unc.length ? `<span class="chip unc sm">要確認 ${unc.length}件</span>` : m.reviewed ? '<span class="chip ok sm">✔ 確認済み</span>' : ''}
      ${(m.files || []).length ? `<span class="chip mute sm" title="${esc(m.files.map(f => f.name).join(', '))}">📎 ${m.files.length}件</span>` : ''}
      ${m.model && m.model !== 'sample' ? `<span class="chip mute sm">${esc(m.model)}</span>` : ''}
    </div>
    ${unc.length ? `<div class="review" role="region" aria-label="読み取りの確認">
      <h3>🔍 読み取りに自信がない箇所</h3>
      <p>Gemini が判読に迷った語句です。紙のメモと見比べて、候補が正しければ「候補で確定」を押してください。</p>
      ${unc.map(u => `<div class="unc-item">
        <span class="where">${esc(u.where)}</span>
        <div class="rd"><s>${esc(u.reading)}</s>${u.guess ? ` → <mark>${esc(u.guess)}</mark>` : ' →（候補なし）'}</div>
        <div class="b">
          ${u.guess ? `<button class="neu btn xs primary" data-act="uc-accept" data-uid="${esc(u.id)}">候補で確定</button>` : ''}
          <button class="neu btn xs" data-act="uc-keep" data-uid="${esc(u.id)}">原文のまま</button>
          <button class="neu btn xs ghost" data-act="uc-edit">手で直す</button>
        </div></div>`).join('')}
    </div>` : ''}
    <p class="summary">${esc(m.summary)}</p>
    <p class="sec-t">議論の流れ</p>
    <ol class="flow">${(m.flow || []).map((f, i) => `<li><div class="s">${esc(f.step)} ${f.uncertain ? uncChip('flow', i) : ''}</div><div class="d">${esc(f.detail)}</div></li>`).join('')}</ol>
    <p class="sec-t">指摘事項</p>
    <ul class="points">${(m.points || []).map((p, i) => {
      const [c, l] = SEV[p.severity] || SEV.mid;
      const t = taskOf(p.id);
      return `<li class="${p.status === 'done' ? 'done' : ''}">
        <button class="cbx" role="checkbox" aria-checked="${p.status === 'done'}" data-act="pt-toggle" data-mid="${esc(m.id)}" data-pid="${esc(p.id)}" aria-label="対応済みにする">✔</button>
        <span class="chip ${c} sm">${l}</span>
        <span class="ptxt">${esc(p.text)} ${p.uncertain ? uncChip('points', i) : ''}</span>
        <span class="acts">${t ? '<span class="chip ok sm">タスク化済</span>' : `<button class="neu btn xs" data-act="pt-task" data-mid="${esc(m.id)}" data-pid="${esc(p.id)}">＋タスク</button>`}</span>
      </li>`;
    }).join('') || '<li><span class="ptxt">指摘はありません</span></li>'}</ul>
    ${(m.decisions || []).length ? `<p class="sec-t">決定事項</p><ul class="points">${m.decisions.map((d, i) =>
      `<li><span class="chip ok sm">決定</span><span class="ptxt">${esc(d.text)} ${d.uncertain ? uncChip('decisions', i) : ''}</span></li>`).join('')}</ul>` : ''}
    <p class="sec-t">抽出されたToDo</p>
    <ul class="points">${(m.todos || []).map((t, i) => {
      const added = t.taskId && S.tasks.some(x => x.id === t.taskId);
      return `<li><span class="ptxt">${esc(t.text)} ${t.uncertain ? uncChip('todos', i) : ''}${t.due ? `<small>⏱ ${esc(/^\d{4}-/.test(t.due) ? md(t.due) : t.due)}</small>` : ''}</span>
        <span class="acts">${added ? '<span class="chip ok sm">追加済</span>' : `<button class="neu btn xs" data-act="todo-add" data-tid="${esc(t.id)}">＋タスクに追加</button>`}</span></li>`;
    }).join('') || '<li><span class="ptxt">ToDo はありません</span></li>'}</ul>`;
}

/** MTG ノート全体を保存（要確認の解消や編集のあと） */
async function saveMeeting(m, extra = {}) {
  const saved = await put('/meetings/' + encodeURIComponent(m.id), { ...m, ...extra });
  S.meetings = S.meetings.map(x => (x.id === saved.id ? saved : x));
  emit('meetings');
  return saved;
}

function textFields(m) {
  // [オブジェクト, キー, 親アイテム] の一覧（置換に使う）
  const out = [[m, 'title', null], [m, 'summary', null]];
  (m.flow || []).forEach(f => { out.push([f, 'step', f], [f, 'detail', f]); });
  ['points', 'decisions', 'todos'].forEach(k => (m[k] || []).forEach(x => out.push([x, 'text', x])));
  return out;
}

async function resolveUnclear(uid, accept) {
  const m = structuredClone(cur());
  const u = m.unclear.find(x => x.id === uid); if (!u) return;
  let replaced = 0;
  if (accept && u.reading && u.guess) {
    for (const [obj, key, item] of textFields(m)) {
      if (typeof obj[key] === 'string' && obj[key].includes(u.reading)) {
        obj[key] = obj[key].split(u.reading).join(u.guess);
        if (item) item.uncertain = false;
        replaced++;
      }
    }
  }
  u.resolved = true;
  const reviewed = m.unclear.every(x => x.resolved);
  try {
    await saveMeeting(m, { reviewed });
    if (accept && !replaced) toast('本文に同じ文字列が見つかりませんでした。必要なら「編集」で直してください', { kind: 'warn', ms: 6000 });
    else if (reviewed) toast('すべての要確認箇所を確認しました');
  } catch (e) { toast(e.message, { kind: 'err' }); }
}

async function onNoteClick(e) {
  const b = e.target.closest('[data-act]'); if (!b || editing) return;
  const m = cur(); if (!m) return;
  const act = b.dataset.act;
  try {
    if (act === 'pt-toggle') await togglePoint(b.dataset.mid, b.dataset.pid);
    else if (act === 'pt-task') await pointToTask(b.dataset.mid, b.dataset.pid);
    else if (act === 'todo-add') {
      const t = m.todos.find(x => x.id === b.dataset.tid);
      b.disabled = true;
      const task = await addTask(t.text, { tag: '', due: t.due, priority: 'mid', source: { type: 'mtg', meetingId: m.id, refId: t.id } });
      if (task) { t.taskId = task.id; renderNote(); }
    } else if (act === 'unc-ok') {
      const c = structuredClone(m);
      c[b.dataset.sec][+b.dataset.i].uncertain = false;
      await saveMeeting(c);
    } else if (act === 'uc-accept') await resolveUnclear(b.dataset.uid, true);
    else if (act === 'uc-keep') await resolveUnclear(b.dataset.uid, false);
    else if (act === 'uc-edit') startEdit();
  } catch (er) { toast(er.message, { kind: 'err' }); }
}

export async function togglePoint(mid, pid) {
  const m = S.meetings.find(x => x.id === mid);
  const p = m?.points.find(x => x.id === pid); if (!p) return;
  const status = p.status === 'done' ? 'open' : 'done';
  const saved = await patch(`/meetings/${encodeURIComponent(mid)}/points/${encodeURIComponent(pid)}`, { status });
  S.meetings = S.meetings.map(x => (x.id === saved.id ? saved : x));
  emit('meetings');
  if (status === 'done') toast('指摘を対応済みにしました', { action: { label: '元に戻す', fn: () => togglePoint(mid, pid) } });
}

async function pointToTask(mid, pid) {
  const m = S.meetings.find(x => x.id === mid);
  const p = m?.points.find(x => x.id === pid); if (!p) return;
  const t = await addTask(p.text, { tag: '指摘', priority: p.severity, source: { type: 'point', meetingId: mid, refId: pid } });
  if (t) { toast('タスクに追加しました'); emit('meetings'); }
}

/* ============================================================
 * 編集モード
 * ========================================================== */
function startEdit() {
  const m = cur(); if (!m) return;
  editing = structuredClone(m);
  editing._orig = structuredClone(m);
  editing._resolveAll = openUnclear(m).length > 0;
  renderNote();
  $('#note .ed')?.focus();
}

function renderEditor() {
  const d = editing;
  const row = (sec, i, inner) => `<div class="ed-row" data-sec="${sec}" data-i="${i}">${inner}<button class="del" data-ed="rm" aria-label="この行を削除">✕</button></div>`;
  const ta = (f, v, rows = 1, ph = '') => `<textarea class="ed" data-f="${f}" rows="${rows}" placeholder="${ph}">${esc(v)}</textarea>`;
  $('#note').innerHTML = `
    <div class="grid2">
      <div class="field" style="margin-top:0"><label>タイトル</label><input class="ed" data-root="title" value="${esc(d.title)}" maxlength="80"></div>
      <div class="field" style="margin-top:0"><label>日付</label><input class="ed" type="date" data-root="date" value="${esc(d.date)}"></div>
    </div>
    <div class="field"><label>要約</label><textarea class="ed" data-root="summary" rows="3">${esc(d.summary)}</textarea></div>
    <p class="sec-t">議論の流れ</p>
    ${d.flow.map((f, i) => row('flow', i, `<div style="flex:1;display:grid;gap:6px">${ta('step', f.step, 1, '見出し')}${ta('detail', f.detail, 2, '説明')}</div>`)).join('')}
    <button class="neu btn xs ed-add" data-ed="add" data-sec="flow">＋ 流れを追加</button>
    <p class="sec-t">指摘事項</p>
    ${d.points.map((p, i) => row('points', i, `<select class="ed" data-f="severity">${['high', 'mid', 'low'].map(s => `<option value="${s}" ${p.severity === s ? 'selected' : ''}>${SEV[s][1]}</option>`).join('')}</select>${ta('text', p.text, 2)}`)).join('')}
    <button class="neu btn xs ed-add" data-ed="add" data-sec="points">＋ 指摘を追加</button>
    <p class="sec-t">決定事項</p>
    ${d.decisions.map((x, i) => row('decisions', i, ta('text', x.text, 1))).join('')}
    <button class="neu btn xs ed-add" data-ed="add" data-sec="decisions">＋ 決定事項を追加</button>
    <p class="sec-t">ToDo</p>
    ${d.todos.map((t, i) => row('todos', i, `${ta('text', t.text, 1)}<input class="ed short" data-f="due" value="${esc(t.due)}" placeholder="期限 (YYYY-MM-DD)">`)).join('')}
    <button class="neu btn xs ed-add" data-ed="add" data-sec="todos">＋ ToDoを追加</button>
    ${openUnclear(d).length ? `<div class="field checks"><label><input type="checkbox" id="ed-resolve" ${d._resolveAll ? 'checked' : ''}> 要確認の ${openUnclear(d).length} 件を確認済みにする</label></div>` : ''}
    <div class="ed-foot">
      <button class="neu btn ghost" data-ed="cancel">キャンセル</button>
      <button class="neu btn primary" data-ed="save">保存</button>
    </div>`;
}

const BLANK = {
  flow: () => ({ step: '', detail: '', uncertain: false }),
  points: () => ({ text: '', severity: 'mid', uncertain: false, status: 'open' }),
  decisions: () => ({ text: '', uncertain: false }),
  todos: () => ({ text: '', due: '', uncertain: false }),
};

function onEditInput(e) {
  if (!editing) return;
  const t = e.target;
  if (t.id === 'ed-resolve') { editing._resolveAll = t.checked; return; }
  if (t.dataset.root) { editing[t.dataset.root] = t.value; return; }
  const r = t.closest('.ed-row'); if (!r || !t.dataset.f) return;
  editing[r.dataset.sec][+r.dataset.i][t.dataset.f] = t.value;
}

async function onEditClick(e) {
  const b = e.target.closest('[data-ed]'); if (!b || !editing) return;
  const act = b.dataset.ed;
  if (act === 'add') { editing[b.dataset.sec].push(BLANK[b.dataset.sec]()); renderEditor(); return; }
  if (act === 'rm') { const r = b.closest('.ed-row'); editing[r.dataset.sec].splice(+r.dataset.i, 1); renderEditor(); return; }
  if (act === 'cancel') { editing = null; renderNote(); return; }
  if (act === 'save') {
    const d = editing, o = d._orig;
    // 文言を直した項目は「要確認」を外す
    for (const sec of ['flow', 'points', 'decisions', 'todos']) {
      d[sec] = d[sec].filter(x => (sec === 'flow' ? x.step || x.detail : x.text).trim());
      d[sec].forEach(x => {
        const before = x.id ? o[sec].find(y => y.id === x.id) : o[sec][d[sec].indexOf(x)];
        if (before && JSON.stringify(before) !== JSON.stringify(x)) x.uncertain = false;
      });
    }
    if (d._resolveAll) d.unclear = (d.unclear || []).map(u => ({ ...u, resolved: true }));
    const reviewed = (d.unclear || []).every(u => u.resolved);
    const { _orig, _resolveAll, ...body } = d;
    b.disabled = true;
    try {
      await saveMeeting(body, { reviewed });
      editing = null;
      renderNote();
      toast('MTGノートを保存しました');
    } catch (er) { toast(er.message, { kind: 'err' }); b.disabled = false; }
  }
}

/* ============================================================
 * 未対応の指摘（全MTG横断）
 * ========================================================== */
function renderOpenPoints() {
  const SO = { high: 0, mid: 1, low: 2 };
  const all = S.meetings.flatMap(m => (m.points || []).map(p => ({ ...p, m })));
  const open = all.filter(p => p.status !== 'done');
  const list = (showAllPoints ? all : open).sort((a, b) =>
    ((a.status === 'done') - (b.status === 'done')) || ((SO[a.severity] ?? 1) - (SO[b.severity] ?? 1)) || (a.m.date < b.m.date ? 1 : -1));
  const hi = open.filter(p => p.severity === 'high').length;
  $('#points-sub').innerHTML = open.length ? `未対応 <b>${open.length}</b> 件${hi ? `（<span style="color:var(--high)">要対応 ${hi}</span>）` : ''}` : '未対応の指摘はありません';
  $('#open-points').innerHTML = list.slice(0, 40).map(p => {
    const [c, l] = SEV[p.severity] || SEV.mid;
    const t = taskOf(p.id);
    return `<li class="${p.status === 'done' ? 'done' : ''}">
      <button class="cbx" role="checkbox" aria-checked="${p.status === 'done'}" data-act="pt-toggle" data-mid="${esc(p.m.id)}" data-pid="${esc(p.id)}" aria-label="対応済みにする">✔</button>
      <span class="ptxt"><span class="chip ${c} sm">${l}</span> ${esc(p.text)}
        <small><a data-act="open" data-mid="${esc(p.m.id)}">${md(p.m.date)}「${esc(p.m.title)}」</a>${t ? ` ・ タスク化済${t.done ? '（完了）' : ''}` : ''}</small></span>
      ${!t && p.status !== 'done' ? `<span class="acts"><button class="neu btn xs" data-act="pt-task" data-mid="${esc(p.m.id)}" data-pid="${esc(p.id)}" aria-label="タスクに追加">＋</button></span>` : ''}
    </li>`;
  }).join('') || '<div class="empty">🎉 未対応の指摘はありません</div>';
}

/* ============================================================
 * MTG 履歴
 * ========================================================== */
function renderHistory() {
  const k = q.trim().toLowerCase();
  const list = S.meetings.filter(m => !k || [m.title, m.summary, ...(m.points || []).map(p => p.text), ...(m.todos || []).map(t => t.text)].join(' ').toLowerCase().includes(k));
  $('#hist-sub').textContent = `${S.meetings.length} 件${k ? `（${list.length} 件ヒット）` : ''}`;
  $('#hist-q').hidden = S.meetings.length < 4 && !k;
  $('#hist').innerHTML = list.map(m => {
    const open = (m.points || []).filter(p => p.status !== 'done').length;
    const unc = openUnclear(m).length;
    return `<li><button data-mid="${esc(m.id)}" aria-current="${m.id === (cur()?.id) ? 'true' : 'false'}">
      <span class="h-t">${esc(m.title)}</span>
      <span class="h-m">${md(m.date)}
        ${open ? `<span class="chip high sm">未対応 ${open}</span>` : '<span class="chip ok sm">指摘すべて対応</span>'}
        ${unc ? `<span class="chip unc sm">要確認 ${unc}</span>` : ''}</span>
    </button></li>`;
  }).join('') || `<div class="empty">${k ? '該当するMTGはありません' : 'まだMTGの記録はありません'}</div>`;
}

export function initMeeting() {
  $('#note').addEventListener('click', e => (editing ? onEditClick(e) : onNoteClick(e)));
  $('#note').addEventListener('input', onEditInput);
  $('#note').addEventListener('change', onEditInput);
  $('#note-edit').onclick = () => { if (editing) { editing = null; renderNote(); } else startEdit(); };
  $('#note-del').onclick = async () => {
    const m = cur(); if (!m) return;
    const ok = await confirmDialog({ title: 'このMTGノートを削除しますか？', body: `${md(m.date)}「${m.title}」と、その指摘の対応状況が消えます。タスクは残ります。`, ok: '削除する', danger: true });
    if (!ok) return;
    try {
      await del('/meetings/' + encodeURIComponent(m.id));
      S.meetings = S.meetings.filter(x => x.id !== m.id);
      sel = S.meetings[0]?.id || null;
      emit('meetings');
      toast('削除しました');
    } catch (e) { toast(e.message, { kind: 'err' }); }
  };
  $('#open-points').addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    try {
      if (b.dataset.act === 'pt-toggle') await togglePoint(b.dataset.mid, b.dataset.pid);
      else if (b.dataset.act === 'pt-task') await pointToTask(b.dataset.mid, b.dataset.pid);
      else if (b.dataset.act === 'open') selectMeeting(b.dataset.mid, { scroll: true });
    } catch (er) { toast(er.message, { kind: 'err' }); }
  });
  $('#points-all').onchange = e => { showAllPoints = e.target.checked; renderOpenPoints(); };
  $('#hist').addEventListener('click', e => { const b = e.target.closest('[data-mid]'); if (b) selectMeeting(b.dataset.mid, { scroll: innerWidth < 1180 }); });
  $('#hist-q').addEventListener('input', debounce(e => { q = e.target.value; renderHistory(); }, 150));
  on('meetings', () => { if (!editing) renderNote(); renderOpenPoints(); renderHistory(); });
  on('tasks', () => { if (!editing) renderNote(); renderOpenPoints(); });
}

export function renderMeetings() {
  renderNote(); renderOpenPoints(); renderHistory();
}
