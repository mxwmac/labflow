// ログイン（Firebase Authentication: Google / 匿名ゲスト）
// AUTH_MODE=dev のときは Firebase を読み込まず、サーバーの固定ユーザーで動く
import { S, $, esc, msg, confirmDialog, toast } from './state.js';

const FB = 'https://www.gstatic.com/firebasejs/13.1.0';
let fb = null; // { auth, mod }

/** API 呼び出し用の ID トークン（期限が近ければ SDK が自動更新する） */
export async function getIdToken() {
  return fb?.auth.currentUser ? fb.auth.currentUser.getIdToken() : null;
}

export async function initAuth({ onSignedIn, onSignedOut }) {
  const cfg = S.cfg;
  if (cfg.authMode === 'dev') {
    onSignedIn();
    return;
  }
  if (!cfg.firebase?.apiKey || !cfg.firebase?.appId) {
    showLogin();
    msg('#login-msg', 'サーバーに Firebase の設定（FIREBASE_API_KEY / FIREBASE_APP_ID）がありません。README の「Firebase の設定」を確認してください。', 'err');
    $('#btn-login-google').disabled = $('#btn-login-guest').disabled = true;
    return;
  }
  const [appMod, mod] = await Promise.all([import(`${FB}/firebase-app.js`), import(`${FB}/firebase-auth.js`)]);
  const app = appMod.initializeApp(cfg.firebase);
  const auth = mod.getAuth(app);
  auth.languageCode = 'ja';
  fb = { auth, mod };

  if (!cfg.allowGuest) {
    $('#btn-login-guest').hidden = true;
    $('#login-note').textContent = 'Google アカウントでログインしてください。';
  }

  $('#btn-login-google').onclick = () => run(() => mod.signInWithPopup(auth, provider()));
  $('#btn-login-guest').onclick = () => run(() => mod.signInAnonymously(auth));

  let first = true;
  mod.onAuthStateChanged(auth, u => {
    if (u) onSignedIn();
    else { if (!first) onSignedOut(); showLogin(); }
    first = false;
  });
}

function provider() {
  const p = new fb.mod.GoogleAuthProvider();
  p.setCustomParameters({ prompt: 'select_account' });
  return p;
}

async function run(fn) {
  msg('#login-msg', '');
  try {
    await fn();
  } catch (e) {
    if (e?.code === 'auth/popup-closed-by-user' || e?.code === 'auth/cancelled-popup-request') return;
    const hint =
      e?.code === 'auth/unauthorized-domain' ? `このドメイン（${location.hostname}）が Firebase の「承認済みドメイン」に登録されていません。`
      : e?.code === 'auth/operation-not-allowed' ? 'Firebase コンソールでこのログイン方法（Google / 匿名）が有効になっていません。'
      : e?.code === 'auth/popup-blocked' ? 'ポップアップがブロックされました。ブラウザの設定で許可してください。'
      : '';
    msg('#login-msg', esc(hint || 'ログインに失敗しました: ' + (e?.message || e)), 'err');
  }
}

export function showLogin() {
  $('#boot').hidden = true;
  $('#app').hidden = true;
  $('#login').hidden = false;
}

export async function logout() {
  if (!fb) { location.reload(); return; }
  if (S.user?.isAnonymous) {
    const ok = await confirmDialog({
      title: 'ゲストのままログアウトしますか？',
      body: 'ゲストのデータは、ログアウトすると二度と開けなくなります。残したい場合は先に「Google アカウントに引き継ぐ」を行ってください。',
      ok: 'ログアウトする', danger: true,
    });
    if (!ok) return;
  }
  await fb.mod.signOut(fb.auth);
}

/** ゲスト → Google アカウントへの引き継ぎ（uid が変わらないのでデータはそのまま残る） */
export async function linkGoogle(after) {
  if (!fb) return;
  const { mod, auth } = fb;
  try {
    await mod.linkWithPopup(auth.currentUser, provider());
    await auth.currentUser.getIdToken(true);
    toast('Google アカウントに引き継ぎました。他の端末からも同じデータを使えます');
    after?.();
  } catch (e) {
    if (e?.code === 'auth/credential-already-in-use') {
      const ok = await confirmDialog({
        title: 'この Google アカウントは既に使われています',
        body: 'そのアカウントには既に LabFlow のデータがあります。切り替えると、いまのゲストのデータは引き継がれません。切り替えますか？',
        ok: '切り替える',
      });
      if (ok) {
        const cred = mod.GoogleAuthProvider.credentialFromError(e);
        await mod.signInWithCredential(auth, cred);
        location.reload();
      }
      return;
    }
    if (e?.code === 'auth/popup-closed-by-user') return;
    toast('引き継ぎに失敗しました: ' + (e?.message || e), { kind: 'err' });
  }
}
