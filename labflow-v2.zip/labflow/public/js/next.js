// 次の一手（Gemini による行動提案）
import { S, $, esc, on, emit, SEV, busy, msg, md } from './state.js';
import { post } from './api.js';
import { addTask } from './tasks.js';
import { getFreeSlots, openEventDialog } from './calendar.js';

function render() {
  const a = S.actions;
  if (!a?.items?.length) return;
  const at = a.at ? new Date(a.at) : null;
  $('#next-sub').textContent = at ? `${at.getMonth() + 1}/${at.getDate()} ${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')} の提案${a.fallback ? '（ルールベース）' : ''}` : '';
  $('#actions').innerHTML = a.items.map((x, i) => {
    const [c, l] = SEV[x.priority] || SEV.mid;
    const added = S.tasks.some(t => t.source?.refId === x.id);
    const cal = x.kind === 'meeting' ? '📅 アポを登録' : x.kind === 'focus' ? '📅 時間を確保' : '';
    return `<div class="act">
      <div class="n"><i>${i + 1}</i><span>${esc(x.title)}</span></div>
      <div class="w">${esc(x.why)}</div>
      <div class="f"><span class="chip ${c} sm">${l}</span>
        <span class="chip mute sm">🕑 ${esc(/^\d{4}-\d{2}-\d{2}$/.test(x.when) ? md(x.when) : x.when)}</span>
        <span class="chip mute sm">⏳ ${esc(x.effort)}</span>
        <span class="btns">
          ${cal ? `<button class="neu btn xs" data-cal="${i}">${cal}</button>` : ''}
          ${added ? '<span class="chip ok sm">タスク化済</span>' : `<button class="neu btn xs" data-add="${i}">＋タスク化</button>`}
        </span></div>
    </div>`;
  }).join('');
}

async function suggest() {
  const btn = $('#suggest');
  btn.disabled = true;
  busy('#actions', 'タスク・未対応の指摘・先生の空き時間・進捗の停滞を整理して提案を作成中…');
  try {
    const r = await post('/suggest', { freeSlots: getFreeSlots() });
    S.actions = r.actions;
    if (r.usage) { S.usage = r.usage; emit('usage'); }
    render();
    if (r.notice) msg($('#actions').appendChild(document.createElement('div')), esc('Gemini を呼び出せなかったため、ルールベースの提案を表示しています: ' + r.notice), 'err');
  } catch (e) {
    msg('#actions', esc(e.message), 'err');
  } finally {
    btn.disabled = false;
  }
}

export function initNext() {
  $('#suggest').onclick = suggest;
  $('#actions').addEventListener('click', async e => {
    const b = e.target.closest('[data-add],[data-cal]'); if (!b) return;
    const x = S.actions.items[+(b.dataset.add ?? b.dataset.cal)];
    if (b.dataset.cal != null) {
      openEventDialog(x.kind === 'meeting'
        ? { kind: 'meeting', slot: x.slot }
        : { kind: 'focus', title: `作業: ${x.title}`, desc: x.why });
      return;
    }
    b.disabled = true;
    const due = /^\d{4}-\d{2}-\d{2}$/.test(x.when) ? x.when : '';
    if (await addTask(x.title, { tag: '提案', priority: x.priority, due, dueText: due ? '' : x.when, source: { type: 'suggest', refId: x.id } })) render();
    else b.disabled = false;
  });
  on('tasks', render);
}
export const renderNext = render;
