// 研究の進捗: リング・フェーズ別スライダー・平均進捗の推移グラフ
import { S, $, $$, esc, on, emit, md, toast, bindSeg, store, ymdLocal } from './state.js';
import { put } from './api.js';

const C = 2 * Math.PI * 44;
const avgOf = ps => (ps.length ? Math.round(ps.reduce((a, p) => a + p.pct, 0) / ps.length) : 0);
let range = +(store('labflow.chartRange') ?? 90);

function pctOn(snap, name, i) {
  return snap?.phases?.find(p => p.name === name)?.pct ?? snap?.phases?.[i]?.pct;
}
/** 14日前と比べて変化のないフェーズ（＝停滞）を返す */
function stalledSet() {
  const cut = new Date(); cut.setDate(cut.getDate() - 14);
  const ref = [...S.progress].reverse().find(p => p.date <= ymdLocal(cut));
  if (!ref) return new Set();
  return new Set(S.phases.filter((p, i) => p.pct < 100 && pctOn(ref, p.name, i) === p.pct).map(p => p.name));
}

function renderRing() {
  const avg = avgOf(S.phases);
  $('#ring-fg').style.strokeDashoffset = C * (1 - avg / 100);
  $('#ring-val').innerHTML = avg + '<span>%</span>';
  // 30日前との差
  const cut = new Date(); cut.setDate(cut.getDate() - 30);
  const ref = [...S.progress].reverse().find(p => p.date <= ymdLocal(cut)) || S.progress[0];
  const d = ref ? avg - ref.avg : 0;
  $('#ring-delta').innerHTML = ref && ref.date !== S.today ? `${md(ref.date)} から <b style="color:${d < 0 ? 'var(--high)' : 'var(--ok)'}">${d >= 0 ? '+' : ''}${d}pt</b>` : '';
}

export function renderProgress() {
  renderRing();
  const stalled = stalledSet();
  $('#phases').innerHTML = S.phases.map((p, i) => `
    <div class="r">
      <div class="r-h"><span>${esc(p.name)}</span>${stalled.has(p.name) ? '<span class="stall" title="14日間変化なし">● 停滞</span>' : ''}<b>${p.pct}%</b></div>
      <div class="bar edit"><i style="width:${p.pct}%"></i>
        <input type="range" min="0" max="100" step="5" value="${p.pct}" data-i="${i}"
               aria-label="${esc(p.name)} の進捗" aria-valuetext="${p.pct}%" title="ドラッグまたは矢印キーで調整"></div>
    </div>`).join('');
  renderChart();
}

/* スライダー: innerHTML を作り直すとドラッグが切れるので、動かす要素だけ書き換える */
function bindSliders() {
  $('#phases').addEventListener('input', e => {
    const sl = e.target.closest('input[type=range]'); if (!sl) return;
    const i = +sl.dataset.i, v = +sl.value;
    S.phases[i].pct = v;
    const row = sl.closest('.r');
    row.querySelector('i').style.width = v + '%';
    row.querySelector('.r-h b').textContent = v + '%';
    sl.setAttribute('aria-valuetext', v + '%');
    renderRing();
  });
  // 保存は指を離した時だけ
  $('#phases').addEventListener('change', async e => {
    if (!e.target.closest('input[type=range]')) return;
    try {
      const r = await put('/phases', { phases: S.phases });
      const i = S.progress.findIndex(p => p.date === r.snapshot.date);
      if (i >= 0) S.progress[i] = r.snapshot; else S.progress.push(r.snapshot);
      renderRing(); renderChart();
      emit('progress');
    } catch (er) { toast(er.message, { kind: 'err' }); }
  });
}

/* ---------- 推移グラフ（単一系列の折れ線 + ホバーで内訳） ---------- */
function renderChart() {
  const el = $('#chart');
  let pts = S.progress.map(p => ({ date: p.date, avg: p.avg, phases: p.phases }));
  if (range) {
    const cut = new Date(); cut.setDate(cut.getDate() - range);
    const cs = ymdLocal(cut);
    pts = pts.filter(p => p.date >= cs);
  }
  if (pts.length < 2) {
    el.innerHTML = `<div class="empty" style="padding-top:40px">スライダーを動かすと日ごとに記録され、<br>ここに推移が表示されます。</div>`;
    return;
  }
  const W = el.clientWidth || 300, H = 150, L = 30, R = 8, T = 10, B = 22;
  const t0 = new Date(pts[0].date).getTime(), t1 = new Date(pts.at(-1).date).getTime();
  const x = d => L + ((new Date(d).getTime() - t0) / Math.max(1, t1 - t0)) * (W - L - R);
  const y = v => T + (1 - v / 100) * (H - T - B);
  const path = pts.map((p, i) => `${i ? 'L' : 'M'}${x(p.date).toFixed(1)},${y(p.avg).toFixed(1)}`).join('');
  const area = `${path}L${x(pts.at(-1).date).toFixed(1)},${y(0)}L${x(pts[0].date).toFixed(1)},${y(0)}Z`;
  const grid = [0, 50, 100].map(v => `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text class="ax" x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${v}</text>`).join('');
  const xt = [pts[0], pts[Math.floor(pts.length / 2)], pts.at(-1)].filter((p, i, a) => a.indexOf(p) === i)
    .map((p, i, a) => `<text class="ax" x="${x(p.date)}" y="${H - 6}" text-anchor="${i === 0 ? 'start' : i === a.length - 1 ? 'end' : 'middle'}">${md(p.date).replace(/\(.\)/, '')}</text>`).join('');
  const last = pts.at(-1);
  el.innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="平均進捗の推移。${md(pts[0].date)} ${pts[0].avg}% から ${md(last.date)} ${last.avg}%">
      <defs><linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="var(--accent)" stop-opacity=".22"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>
      ${grid}${xt}
      <path class="ar" d="${area}"/><path class="ln" d="${path}"/>
      <circle class="pt" cx="${x(last.date)}" cy="${y(last.avg)}" r="4"/>
      <line class="xh" id="xh" y1="${T}" y2="${H - B}" visibility="hidden"/>
      <circle class="pt" id="xp" r="5" visibility="hidden"/>
      <rect class="hit" x="${L}" y="0" width="${W - L - R}" height="${H}"/>
    </svg><div class="tip" id="tip" hidden></div>`;
  const svg = $('svg', el), tip = $('#tip', el), xh = $('#xh', el), xp = $('#xp', el);
  const show = clientX => {
    const r = svg.getBoundingClientRect();
    const px = ((clientX - r.left) / r.width) * W;
    const p = pts.reduce((b, q) => (Math.abs(x(q.date) - px) < Math.abs(x(b.date) - px) ? q : b));
    const cx = x(p.date), cy = y(p.avg);
    xh.setAttribute('x1', cx); xh.setAttribute('x2', cx); xh.setAttribute('visibility', 'visible');
    xp.setAttribute('cx', cx); xp.setAttribute('cy', cy); xp.setAttribute('visibility', 'visible');
    tip.hidden = false;
    tip.style.left = Math.min(Math.max((cx / W) * r.width, 80), r.width - 80) + 'px';
    tip.style.top = (cy / H) * r.height - 10 + 'px';
    tip.innerHTML = `<span class="k">${md(p.date)}</span><br><b>平均 ${p.avg}%</b><table>${(p.phases || []).map(f => `<tr><td>${esc(f.name)}</td><td>${f.pct}%</td></tr>`).join('')}</table>`;
  };
  const hide = () => { tip.hidden = true; xh.setAttribute('visibility', 'hidden'); xp.setAttribute('visibility', 'hidden'); };
  const hit = $('.hit', el);
  hit.addEventListener('pointermove', e => show(e.clientX));
  hit.addEventListener('pointerdown', e => show(e.clientX));
  hit.addEventListener('pointerleave', hide);
}

export function initProgress() {
  bindSliders();
  const seg = $('#chart-range');
  $$('button', seg).forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.r === range)));
  bindSeg(seg, 'r', v => { range = +v; store('labflow.chartRange', String(range)); renderChart(); });
  let w = 0;
  new ResizeObserver(() => { const nw = $('#chart').clientWidth; if (nw !== w) { w = nw; renderChart(); } }).observe($('#chart'));
  on('phases', renderProgress);
}
