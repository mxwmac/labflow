// 指導教員の予定（Google Calendar API）・空き時間の抽出・予定の登録
// OAuth のアクセストークンはブラウザのメモリ上だけで扱い、サーバーには送らない
import { S, $, esc, on, emit, WD, hm, pad, md, ymdLocal, msg, err, setStatus, toast, bindSeg, setSeg, segValue, store } from './state.js';

const SCOPE_READ = 'https://www.googleapis.com/auth/calendar.readonly';
const SCOPE_WRITE = 'https://www.googleapis.com/auth/calendar.events';
const API = 'https://www.googleapis.com/calendar/v3';

const CAL = {
  token: null, exp: 0, granted: '',
  mode: 'demo',       // demo | google | freebusy | off
  teacher: [],        // 先生の予定 {start,end,title,kind,allDay,busy}
  mine: [],           // 自分の予定（空き計算用）{start,end,title,kind:'mine'}
  loaded: null,       // {from,to}
  weekOffset: 0,
  demoAdded: [],
  slotIndex: new Map(),
};

const isEmail = s => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s || '');
const teacherId = () => S.settings.calId || 'primary';
const connected = () => CAL.mode === 'google' || CAL.mode === 'freebusy';

function weekStart(off) {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  const dow = (d.getDay() + 6) % 7; // 月曜=0
  d.setDate(d.getDate() - dow + off * 7);
  return d;
}
const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

/* ---------- デモデータ ---------- */
function demoWeek(base) {
  const mk = (dayIdx, h, m, dur, title, kind = '') => {
    const s = addD(base, dayIdx); s.setHours(h, m, 0, 0);
    const e = new Date(s); e.setMinutes(e.getMinutes() + dur);
    return { start: s, end: e, title, kind, busy: true, allDay: kind === 'away' };
  };
  const away = (dayIdx, title) => { const s = addD(base, dayIdx); return { start: s, end: addD(s, 1), title, kind: 'away', busy: true, allDay: true }; };
  return {
    teacher: [
      mk(0, 9, 0, 90, '学科会議', 'busy'), mk(0, 13, 0, 90, '学部講義 情報工学'),
      mk(1, 10, 30, 60, 'B4 ゼミ'), mk(1, 15, 0, 60, '研究室全体ゼミ'),
      away(2, '学会出張（名古屋）'),
      mk(3, 11, 0, 60, '共同研究 打合せ', 'busy'), mk(3, 16, 0, 30, '院生 個別面談'),
      mk(4, 13, 0, 90, '学部講義 情報工学'),
    ],
    mine: [mk(1, 13, 0, 90, 'TA（プログラミング演習）', 'mine'), mk(3, 14, 0, 60, '輪講準備', 'mine')],
  };
}
function demoRange(from, to) {
  const out = { teacher: [], mine: [] };
  for (let w = new Date(from); w < to; w = addD(w, 7)) {
    const d = demoWeek(w);
    out.teacher.push(...d.teacher);
    out.mine.push(...d.mine);
  }
  return out;
}

/* ---------- Google Identity Services（OAuth トークン） ---------- */
let gisPromise;
export function loadGis() {
  if (window.google?.accounts?.oauth2) return Promise.resolve();
  gisPromise ||= new Promise((ok, ng) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client'; s.async = true;
    s.onload = ok; s.onerror = () => { gisPromise = null; ng(new Error('Google 認証スクリプトを読み込めませんでした')); };
    document.head.appendChild(s);
  });
  return gisPromise;
}
const hasScope = scope => CAL.granted.split(' ').includes(scope);

async function ensureToken(scope) {
  if (CAL.token && Date.now() < CAL.exp - 60_000 && hasScope(scope)) return CAL.token;
  if (!S.cfg.oauthClientId) throw new Error('サーバーに OAUTH_CLIENT_ID が設定されていません（README の手順を参照）');
  if (location.protocol === 'file:') throw new Error('file:// では Google 認証を使えません');
  await loadGis();
  const resp = await new Promise((resolve, reject) => {
    const tc = google.accounts.oauth2.initTokenClient({
      client_id: S.cfg.oauthClientId,
      scope,
      include_granted_scopes: true,
      callback: r => (r.error ? reject(new Error(r.error_description || r.error)) : resolve(r)),
      error_callback: e => reject(new Error(e?.type === 'popup_closed' ? 'Google の認可画面が閉じられました' : e?.type === 'popup_failed_to_open' ? 'ポップアップを開けませんでした（ブロックを解除してください）' : (e?.message || '認可に失敗しました'))),
    });
    tc.requestAccessToken({ prompt: '', login_hint: S.user?.email || undefined });
  });
  CAL.token = resp.access_token;
  CAL.exp = Date.now() + (resp.expires_in || 3600) * 1000;
  CAL.granted = [CAL.granted, resp.scope || scope].join(' ');
  if (!hasScope(scope)) throw new Error('カレンダーへのアクセスが許可されませんでした');
  return CAL.token;
}

async function gcal(path, init = {}) {
  const r = await fetch(API + path, { ...init, headers: { Authorization: 'Bearer ' + CAL.token, 'Content-Type': 'application/json', ...(init.headers || {}) } });
  if (!r.ok) {
    const j = await r.json().catch(() => null);
    const e = new Error(j?.error?.message || `Calendar API ${r.status}`);
    e.status = r.status;
    throw e;
  }
  return r.status === 204 ? null : r.json();
}

const KIND_RE = /会議|出張|審査|講義|授業|教授会|委員会|試験/;
function mapEvent(it) {
  const allDay = !!it.start?.date;
  return {
    start: new Date(it.start.dateTime || it.start.date + 'T00:00:00'),
    end: new Date(it.end.dateTime || it.end.date + 'T00:00:00'),
    title: it.summary || '(予定あり)',
    kind: allDay ? 'away' : KIND_RE.test(it.summary || '') ? 'busy' : '',
    allDay,
    busy: it.transparency !== 'transparent',
    link: it.htmlLink,
  };
}

async function freeBusy(ids, from, to) {
  const j = await gcal('/freeBusy', { method: 'POST', body: JSON.stringify({ timeMin: from.toISOString(), timeMax: to.toISOString(), items: ids.map(id => ({ id })) }) });
  return ids.map(id => {
    const c = j.calendars?.[id];
    if (c?.errors?.length) throw Object.assign(new Error(`カレンダー「${id}」を読めません（${c.errors[0].reason}）`), { status: 404 });
    return (c?.busy || []).map(b => ({ start: new Date(b.start), end: new Date(b.end) }));
  });
}

async function loadGoogle(from, to) {
  const tid = teacherId();
  let teacher, mode = 'google';
  try {
    const q = new URLSearchParams({ timeMin: from.toISOString(), timeMax: to.toISOString(), singleEvents: 'true', orderBy: 'startTime', maxResults: '500' });
    const j = await gcal(`/calendars/${encodeURIComponent(tid)}/events?${q}`);
    teacher = (j.items || []).filter(it => it.status !== 'cancelled').map(mapEvent);
  } catch (e) {
    // 「予定の有無のみ」共有の場合は events.list が使えないので freeBusy で代替する
    if (e.status !== 403 && e.status !== 404) throw e;
    const [busy] = await freeBusy([tid], from, to);
    teacher = busy.map(b => ({ ...b, title: '予定あり', kind: 'busy', allDay: false, busy: true }));
    mode = 'freebusy';
  }
  let mine = [];
  if (S.settings.includeMine && tid !== 'primary') {
    try {
      const [busy] = await freeBusy(['primary'], from, to);
      mine = busy.map(b => ({ ...b, title: '自分の予定', kind: 'mine', busy: true }));
    } catch (e) { /* 自分の予定が読めなくても先生の予定は表示する */ }
  }
  Object.assign(CAL, { teacher, mine, mode, loaded: { from, to } });
}

async function ensureLoaded() {
  const need = { from: weekStart(CAL.weekOffset), to: weekStart(CAL.weekOffset + 2) };
  if (CAL.loaded && CAL.loaded.from <= need.from && CAL.loaded.to >= need.to) return;
  const from = weekStart(CAL.weekOffset - 1), to = weekStart(CAL.weekOffset + 3);
  if (connected()) {
    await ensureToken(SCOPE_READ);
    await loadGoogle(from, to);
  } else if (S.settings.demoCal) {
    const d = demoRange(from, to);
    Object.assign(CAL, { teacher: d.teacher, mine: S.settings.includeMine ? d.mine : [], mode: 'demo', loaded: { from, to } });
  } else {
    Object.assign(CAL, { teacher: [], mine: [], mode: 'off', loaded: { from, to } });
  }
}

/* ---------- 空き時間の計算 ---------- */
const overlaps = (e, a, b) => e.start < b && e.end > a;
function eventsOn(day) {
  const next = addD(day, 1);
  const t = [...CAL.teacher, ...CAL.demoAdded.filter(e => e.who === 'teacher')].filter(e => overlaps(e, day, next));
  const m = [...CAL.mine, ...CAL.demoAdded.filter(e => e.who !== 'teacher')].filter(e => overlaps(e, day, next));
  return { t, m };
}

function slotsOn(day) {
  const dow = day.getDay();
  if (dow === 0 || dow === 6) return [];
  const { t, m } = eventsOn(day);
  const ws = S.settings.workStart ?? 10, we = S.settings.workEnd ?? 18, min = S.settings.minSlot ?? 60;
  let cursor = new Date(day); cursor.setHours(ws, 0, 0, 0);
  const end = new Date(day); end.setHours(we, 0, 0, 0);
  const now = new Date();
  if (cursor < now) { // 今日は「今」以降。15分単位に切り上げ
    cursor = new Date(now); cursor.setSeconds(0, 0);
    cursor.setMinutes(Math.ceil(cursor.getMinutes() / 15) * 15);
  }
  if (cursor >= end) return [];
  const blocks = [...t, ...m].filter(e => e.busy !== false).sort((a, b) => a.start - b.start);
  const out = [];
  for (const ev of [...blocks, { start: end, end }]) {
    if (ev.start > cursor) {
      const len = (Math.min(ev.start, end) - cursor) / 60000;
      if (len >= min) out.push({ from: new Date(cursor), len });
    }
    if (ev.end > cursor) cursor = new Date(Math.max(cursor, ev.end));
    if (cursor >= end) break;
  }
  return out;
}

const hrs = len => (len % 60 ? `${Math.round((len / 60) * 10) / 10}h` : `${len / 60}h`);
function slotLabel(day, s) {
  const to = new Date(s.from.getTime() + s.len * 60000);
  return `${day.getMonth() + 1}/${day.getDate()}(${WD[day.getDay()]}) ${hm(s.from)}〜${hm(to)}`;
}
function indexSlot(day, s) {
  const label = slotLabel(day, s);
  CAL.slotIndex.set(label, { date: ymdLocal(day), time: hm(s.from), len: s.len });
  return label;
}

/** AI・報告書に渡す「先生の空き時間」（今日から2週間、各日の最長枠） */
export function getFreeSlots() {
  if (CAL.mode === 'off') return [];
  const out = [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (let i = 0; i < 14 && out.length < 8; i++) {
    const day = addD(today, i);
    // 表示中の週によっては今日付近のデータを読み込んでいないので、読み込み済みの範囲だけを使う
    if (!CAL.loaded || day < CAL.loaded.from || day >= CAL.loaded.to) continue;
    const best = slotsOn(day).sort((a, b) => b.len - a.len)[0];
    if (best) out.push(indexSlot(day, best));
  }
  return out;
}

/* ---------- 描画 ---------- */
export async function renderWeek() {
  let ok = true;
  try {
    await ensureLoaded();
  } catch (e) {
    ok = false;
    err('#cal-msg', 'カレンダーの取得に失敗: ' + e.message + (e.status === 404 ? '（カレンダーIDと共有設定を確認してください）' : ''));
  }
  const base = weekStart(CAL.weekOffset);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  let html = '';
  for (let i = 0; i < 7; i++) {
    const day = addD(base, i);
    const { t, m } = eventsOn(day);
    const evs = [...t.map(e => ({ ...e, who: 't' })), ...m.map(e => ({ ...e, who: 'm' }))].sort((a, b) => a.start - b.start);
    const cls = [+day === +today ? 'today' : '', day < today ? 'past' : '', i === 5 ? 'sat' : '', i === 6 ? 'sun' : ''].join(' ');
    const slots = i < 5 && day >= today ? slotsOn(day) : [];
    const slotHtml = i >= 5 ? '' : day < today ? '' : slots.length
      ? slots.slice(0, 2).map(s => {
          const label = indexSlot(day, s);
          return `<button class="slot" data-slot="${esc(label)}" title="${esc(label)} に予定を登録">空き ${hm(s.from)}〜 ${hrs(s.len)}</button>`;
        }).join('') + (slots.length > 2 ? `<span class="slot none">ほか${slots.length - 2}枠</span>` : '')
      : '<span class="slot none">空きなし</span>';
    html += `<div class="day ${cls}">
      <div class="d-h"><b>${day.getDate()}</b>${WD[day.getDay()]}</div>
      ${evs.map(e => `<div class="ev ${e.who === 'm' ? 'mine' : esc(e.kind)} ${e.isNew ? 'new' : ''}" ${e.busy === false ? 'style="opacity:.55"' : ''}>
        <b>${e.allDay ? '終日' : hm(e.start) + '–' + hm(e.end)}</b>${esc(e.who === 'm' && CAL.mode !== 'demo' && !e.isNew ? '自分の予定' : e.title)}</div>`).join('')}
      <div class="slots">${slotHtml}</div>
    </div>`;
  }
  $('#week').innerHTML = html;
  const wk = CAL.weekOffset === 0 ? '今週' : CAL.weekOffset > 0 ? `${CAL.weekOffset}週後` : `${-CAL.weekOffset}週前`;
  const src = { google: 'Googleカレンダー同期中', freebusy: 'Google（予定の有無のみ）', demo: 'デモデータ表示中', off: '未接続' }[CAL.mode];
  $('#cal-sub').textContent = `${wk}（${md(ymdLocal(base))}〜）／ ${src} ／ ${S.settings.workStart}:00〜${S.settings.workEnd}:00 の ${S.settings.minSlot}分以上の空き`;
  setStatus('#st-cal', connected() ? 'カレンダー: 同期済み' : S.cfg.oauthClientId ? 'カレンダー: 未接続' : 'カレンダー: デモ', connected() ? 'ok' : 'mute');
  $('#cal-connect').textContent = connected() ? '↻ 再読込' : 'Google連携';
  emit('slots');
  return ok;
}

function reload() { CAL.loaded = null; return renderWeek(); }

/* ---------- 予定の登録 ---------- */
let evCtx = {};
export function openEventDialog({ kind = 'meeting', title = '', desc = '', slot = '', date = '', time = '', dur = 0 } = {}) {
  let pre = slot && CAL.slotIndex.get(slot);
  if (!pre && !date && kind === 'meeting') {
    const first = getFreeSlots()[0];
    pre = first && CAL.slotIndex.get(first);
  }
  const tomorrow = ymdLocal(addD(new Date(), 1));
  evCtx = { titleTouched: !!title, descTouched: !!desc };
  setSeg($('#ev-kind'), 'k', kind);
  $('#ev-title').value = title || defaultTitle(kind);
  $('#ev-date').value = date || pre?.date || tomorrow;
  $('#ev-time').value = time || pre?.time || `${pad(S.settings.workStart ?? 10)}:00`;
  $('#ev-dur').value = String(dur || (kind === 'meeting' ? 30 : Math.min(120, Math.max(60, Math.floor((pre?.len || 60) / 30) * 30))));
  if (![...$('#ev-dur').options].some(o => o.value === $('#ev-dur').value)) $('#ev-dur').value = '60';
  $('#ev-desc').value = desc || defaultDesc(kind);
  $('#ev-sub').textContent = connected()
    ? '自分の Google カレンダー（primary）に登録します。'
    : 'Google 未連携のため、画面上のデモ予定として追加します（実際のカレンダーには登録されません）。';
  syncKind();
  $('#dlg-event').showModal();
  checkOverlap();
}
function defaultTitle(kind) {
  return kind === 'meeting' ? `研究相談（${S.user?.name || '学生'}）` : '作業時間';
}
function defaultDesc(kind) {
  if (kind !== 'meeting') return '';
  const pts = S.meetings.flatMap(m => (m.points || []).filter(p => p.status !== 'done' && p.severity === 'high').map(p => `・${p.text}`)).slice(0, 4);
  return pts.length ? `相談したいこと:\n${pts.join('\n')}` : '相談したいこと:\n・';
}
function syncKind() {
  const kind = segValue($('#ev-kind'), 'k');
  const calId = S.settings.calId;
  $('#ev-invite-row').hidden = !(kind === 'meeting' && isEmail(calId) && connected());
  $('#ev-teacher').textContent = calId;
  $('#ev-invite').checked = false;
}
function checkOverlap() {
  const kind = segValue($('#ev-kind'), 'k');
  const s = new Date(`${$('#ev-date').value}T${$('#ev-time').value || '00:00'}`);
  const e = new Date(s.getTime() + +$('#ev-dur').value * 60000);
  if (isNaN(s)) { msg('#ev-warn', ''); return; }
  const day = new Date(s); day.setHours(0, 0, 0, 0);
  const { t, m } = eventsOn(day);
  const hitT = t.filter(x => x.busy !== false && overlaps(x, s, e));
  const hitM = m.filter(x => overlaps(x, s, e));
  const warn = [];
  if (kind === 'meeting' && hitT.length) warn.push(`先生の予定（${hitT.map(x => x.allDay ? '終日: ' + x.title : hm(x.start) + '– ' + x.title).join('、')}）と重なっています`);
  if (hitM.length) warn.push('自分の予定と重なっています');
  if (s < new Date()) warn.push('過去の日時です');
  msg('#ev-warn', warn.map(esc).join('<br>'), 'err');
}

async function submitEvent() {
  const kind = segValue($('#ev-kind'), 'k');
  const title = $('#ev-title').value.trim();
  const s = new Date(`${$('#ev-date').value}T${$('#ev-time').value}`);
  if (!title || isNaN(s)) { msg('#ev-warn', 'タイトルと日時を入力してください', 'err'); return; }
  const e = new Date(s.getTime() + +$('#ev-dur').value * 60000);
  const desc = $('#ev-desc').value.trim();
  const btn = $('#ev-ok');
  if (!connected()) {
    CAL.demoAdded.push({ start: s, end: e, title, kind: 'mine', busy: true, isNew: true, who: 'me' });
    $('#dlg-event').close();
    toast('デモ予定として追加しました（実際のカレンダーには登録されていません）', { kind: 'warn' });
    renderWeek();
    return;
  }
  btn.disabled = true;
  msg('#ev-warn', '<span class="spin"></span>Google カレンダーに登録しています…');
  try {
    await ensureToken(SCOPE_WRITE);
    const invite = !$('#ev-invite-row').hidden && $('#ev-invite').checked;
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || S.cfg.timeZone;
    const body = {
      summary: title,
      description: (desc ? desc + '\n\n' : '') + '— LabFlow から登録',
      start: { dateTime: s.toISOString(), timeZone: tz },
      end: { dateTime: e.toISOString(), timeZone: tz },
      ...(invite ? { attendees: [{ email: S.settings.calId }] } : {}),
      extendedProperties: { private: { labflow: kind } },
    };
    const ev = await gcal(`/calendars/primary/events?sendUpdates=${invite ? 'all' : 'none'}`, { method: 'POST', body: JSON.stringify(body) });
    $('#dlg-event').close();
    toast(invite ? '登録し、先生に招待を送りました' : 'Google カレンダーに登録しました', { action: ev.htmlLink ? { label: 'カレンダーで開く', href: ev.htmlLink } : undefined, ms: 7000 });
    await reload();
  } catch (er) {
    msg('#ev-warn', esc('登録に失敗しました: ' + er.message), 'err');
  } finally {
    btn.disabled = false;
  }
}

/* ---------- 初期化 ---------- */
export function initCalendar() {
  $('#cal-prev').onclick = () => { CAL.weekOffset--; renderWeek(); };
  $('#cal-next').onclick = () => { CAL.weekOffset++; renderWeek(); };
  $('#cal-today').onclick = () => { CAL.weekOffset = 0; renderWeek(); };
  $('#cal-connect').onclick = async () => {
    if (!S.cfg.oauthClientId) { msg('#cal-msg', 'サーバーに OAUTH_CLIENT_ID が設定されていないため、デモ表示のみです。'); return; }
    msg('#cal-msg', '<span class="spin"></span>Google カレンダーに接続しています…');
    try {
      await ensureToken(SCOPE_READ);
      CAL.mode = 'google';
      if (await reload()) msg('#cal-msg', CAL.mode === 'freebusy' ? esc('先生のカレンダーは「予定の有無のみ」共有のため、予定名は表示されません。') : '');
      store('labflow.calLinked', '1');
    } catch (e) {
      if (!connected()) CAL.mode = S.settings.demoCal ? 'demo' : 'off';
      err('#cal-msg', e.message);
    }
  };
  $('#week').addEventListener('click', e => {
    const b = e.target.closest('[data-slot]'); if (!b) return;
    openEventDialog({ kind: 'meeting', slot: b.dataset.slot });
  });
  bindSeg($('#ev-kind'), 'k', k => {
    if (!evCtx.titleTouched) $('#ev-title').value = defaultTitle(k);
    if (!evCtx.descTouched) $('#ev-desc').value = defaultDesc(k);
    syncKind(); checkOverlap();
  });
  $('#ev-title').addEventListener('input', () => { evCtx.titleTouched = true; });
  $('#ev-desc').addEventListener('input', () => { evCtx.descTouched = true; });
  ['#ev-date', '#ev-time', '#ev-dur'].forEach(s => $(s).addEventListener('input', checkOverlap));
  $('#ev-form').addEventListener('submit', e => {
    if (e.submitter?.value !== 'ok') return;
    e.preventDefault();
    if (!$('#ev-form').reportValidity()) return;
    submitEvent();
  });
  if (S.cfg.oauthClientId) loadGis().catch(() => {}); // ポップアップがブロックされないよう先読み
  on('settings', () => { if (!connected()) CAL.mode = S.settings.demoCal ? 'demo' : 'off'; reload(); });
}

export function revokeCalendar() {
  if (CAL.token && window.google?.accounts?.oauth2) google.accounts.oauth2.revoke(CAL.token, () => {});
  CAL.token = null;
}
