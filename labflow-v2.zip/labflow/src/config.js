// =============================================================
// 設定値はすべて環境変数から読む（Cloud Run の --set-env-vars で渡す）
// =============================================================
const env = process.env;
const list = (v, d = []) => (v ? v.split(',').map(s => s.trim()).filter(Boolean) : d);
const int = (v, d) => (Number.isFinite(parseInt(v, 10)) ? parseInt(v, 10) : d);
const bool = (v, d) => (v == null || v === '' ? d : /^(1|true|yes|on)$/i.test(v));

const onCloudRun = !!env.K_SERVICE;

export const config = {
  port: int(env.PORT, 8080),
  onCloudRun,
  projectId: env.GOOGLE_CLOUD_PROJECT || env.GCLOUD_PROJECT || '',
  timeZone: env.APP_TZ || 'Asia/Tokyo',

  // 認証: firebase = Firebase Authentication の ID トークンを検証 / dev = ローカル専用の固定ユーザー
  authMode: env.AUTH_MODE || 'firebase',
  allowGuest: bool(env.ALLOW_GUEST, true),
  allowedEmailDomains: list(env.ALLOWED_EMAIL_DOMAINS),

  // 保存先: firestore / memory（ローカル試用・テスト用。再起動で消える）
  store: env.STORE || 'firestore',
  firestoreDatabase: env.FIRESTORE_DATABASE || '(default)',

  // Gemini: vertex = Vertex AI（サービスアカウント認証・APIキー不要）/ apikey = Gemini Developer API / mock = 固定応答
  aiMode: env.AI_MODE || 'vertex',
  geminiLocation: env.GEMINI_LOCATION || 'global',
  geminiApiKey: env.GEMINI_API_KEY || '',
  models: list(env.GEMINI_MODELS, ['gemini-3.8-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-pro-preview']),
  defaultModel: env.GEMINI_MODEL || 'gemini-3.8-flash',

  // 1ユーザー1日あたりの AI 呼び出し上限（コストの暴走防止）
  dailyLimit: int(env.AI_DAILY_LIMIT, 60),
  guestDailyLimit: int(env.GUEST_DAILY_LIMIT, 20),
  maxUploadMB: int(env.MAX_UPLOAD_MB, 18),

  // ブラウザに渡す公開設定（秘密情報ではない）
  firebase: {
    apiKey: env.FIREBASE_API_KEY || '',
    authDomain: env.FIREBASE_AUTH_DOMAIN || (env.GOOGLE_CLOUD_PROJECT ? `${env.GOOGLE_CLOUD_PROJECT}.firebaseapp.com` : ''),
    projectId: env.GOOGLE_CLOUD_PROJECT || '',
    appId: env.FIREBASE_APP_ID || '',
  },
  oauthClientId: env.OAUTH_CLIENT_ID || '',
};

if (!config.models.includes(config.defaultModel)) config.models.unshift(config.defaultModel);

// 開発用の認証バイパスを本番で有効にしてしまう事故を防ぐ
if (config.authMode === 'dev' && onCloudRun) {
  console.error('AUTH_MODE=dev は Cloud Run 上では使えません。起動を中止します。');
  process.exit(1);
}
