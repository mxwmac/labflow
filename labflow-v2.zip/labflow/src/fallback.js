// Gemini を使わない（AI_MODE=mock）とき・Gemini が失敗したときの代替ロジック。
// ルールベースなので内容は単純だが、画面の動作確認やデモはこれで行える。
import { REPORT_KINDS } from './prompts.js';
import { addDays, newId } from './util.js';

export function mockNote({ fileCount, today }) {
  return {
    title: '（デモ解析）実験計画の見直し',
    date: today,
    summary: `デモモードのため、画像 ${fileCount} 件の実際の内容ではなく固定のサンプルを表示しています。Gemini を有効にすると手書きメモから抽出されます。`,
    confidence: 'mid',
    flow: [
      { step: '前回指摘の確認', detail: '正規化の比較結果を報告。差は小さいが per-image の方が安定。', uncertain: false },
      { step: '評価の妥当性', detail: 'テスト画像の選び方に偏りがないか議論。', uncertain: false },
      { step: '今後の計画', detail: '交差検証に切り替え、□□ 分割で再評価する。', uncertain: true },
    ],
    points: [
      { text: '交差検証で結果のばらつきを示すこと', severity: 'high', uncertain: false },
      { text: 'テスト画像の撮影条件を表にまとめること', severity: 'mid', uncertain: false },
      { text: '学習率は □e-4 で固定してよい', severity: 'low', uncertain: true },
    ],
    decisions: [{ text: '正規化は per-image 方式を採用する', uncertain: false }],
    todos: [
      { text: '5分割交差検証のスクリプトを書く', due: addDays(today, 5), uncertain: false },
      { text: '撮影条件の一覧表を作る', due: '', uncertain: false },
    ],
    unclear: [
      { reading: '□□ 分割で再評価', guess: '5 分割で再評価', where: '議論の流れ「今後の計画」' },
      { reading: '学習率は □e-4', guess: '学習率は 1e-4', where: '指摘事項 3件目' },
    ],
  };
}

const PRI = { high: 0, mid: 1, low: 2 };

export function ruleActions(ctx) {
  const out = [];
  const overdue = ctx.openTasks.filter(t => t.overdue);
  const highPoint = ctx.openPoints.find(p => p.severity === 'high');
  if (overdue[0]) {
    out.push({ title: `期限切れの「${overdue[0].title}」を今日中に区切りまで進める`, why: `期限（${overdue[0].due}）を過ぎています。途中経過でも共有すると次の相談がしやすくなります。`, when: '今日', effort: '2時間', priority: 'high', kind: 'task', slot: '' });
  } else if (highPoint) {
    out.push({ title: `指摘「${highPoint.text}」への対応を1枚の図にまとめる`, why: `${highPoint.meeting} の重要な指摘がまだ未対応です。`, when: '今日 午後', effort: '2〜3時間', priority: 'high', kind: 'focus', slot: '' });
  }
  const slot = ctx.freeSlots[0];
  if (slot) {
    out.push({ title: '先生に15分の相談アポを入れる', why: `未対応の指摘が ${ctx.openPoints.length} 件あります。方針を早めにすり合わせると手戻りが減ります。`, when: slot, effort: '15分', priority: 'high', kind: 'meeting', slot });
  }
  const stalled = ctx.phases.filter(p => p.pct < 100 && p.pct === p.pct14).sort((a, b) => a.pct - b.pct)[0];
  if (stalled) {
    out.push({ title: `「${stalled.name}」を進める小さな作業を1つ終わらせる`, why: `この2週間、${stalled.name} の進捗が ${stalled.pct}% のまま止まっています。`, when: '明日 午前', effort: '1時間', priority: 'mid', kind: 'focus', slot: '' });
  }
  const next = [...ctx.openTasks].sort((a, b) => (PRI[a.priority] ?? 1) - (PRI[b.priority] ?? 1))[0];
  if (next && out.length < 3) {
    out.push({ title: `「${next.title}」に着手する`, why: '未完了タスクの中で優先度が最も高いものです。', when: next.due || '今週', effort: '1〜2時間', priority: next.priority || 'mid', kind: 'task', slot: '' });
  }
  if (!out.length) {
    out.push({ title: '今週の目標を3つ書き出してタスクに登録する', why: 'タスクや指摘が登録されていないため、まず計画を立てましょう。', when: '今日', effort: '15分', priority: 'mid', kind: 'task', slot: '' });
  }
  return out.slice(0, 3);
}

export function templateReport(kind, ctx) {
  const ph = ctx.phases.map(p => `| ${p.name} | ${p.pctStart}% | ${p.pct}% |`).join('\n');
  const done = ctx.doneTasks.map(t => `- ${t.title}`).join('\n') || '- （期間内に完了したタスクはありません）';
  const open = ctx.openTasks.slice(0, 6).map(t => `- ${t.title}${t.due ? `（期限 ${t.due}）` : ''}`).join('\n') || '- （未完了タスクはありません）';
  const pts = ctx.openPoints.slice(0, 5).map(p => `- ${p.text}（${p.meeting}）`).join('\n') || '- （未対応の指摘はありません）';
  const fixed = ctx.resolvedPoints.map(p => `- ${p.text}`).join('\n') || '- （期間内に対応済みにした指摘はありません）';
  const table = `| フェーズ | 期間開始 | 現在 |\n|---|---|---|\n${ph}`;

  if (kind === 'email') {
    const slots = ctx.freeSlots.slice(0, 3).map(s => `- ${s}`).join('\n') || '- ご都合のよい日時をお知らせいただけますと幸いです';
    return `件名: 研究のご相談のお願い（${ctx.topic || '研究'}）

○○先生

お世話になっております。（氏名）です。
現在の研究について、15分ほどご相談のお時間をいただけないでしょうか。

ご相談したい点:
${ctx.openPoints.slice(0, 3).map(p => `- ${p.text}`).join('\n') || '- 今後の進め方について'}

候補日時:
${slots}

お忙しいところ恐縮ですが、よろしくお願いいたします。

（氏名）`;
  }
  if (kind === 'seminar') {
    return `## 研究テーマ
${ctx.topic || '（未設定）'}

## 前回からの進捗
${table}

## 前回の指摘への対応状況
${fixed}

## 課題と相談したいこと
${pts}

## 次回までの予定
${open}`;
  }
  return `## 今週やったこと（${ctx.from} 〜 ${ctx.today}）
${done}

## 進捗率
${table}

## 指摘への対応
${fixed}

## 困っていること
${pts}

## 来週やること
${open}`;
}

export const reportTitle = (kind, ctx) => `${REPORT_KINDS[kind] || '報告'}（${ctx.from}〜${ctx.today}）`;

export const withIds = list => list.map(x => ({ id: newId(), ...x }));
