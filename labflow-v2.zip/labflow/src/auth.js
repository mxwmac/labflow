import { config } from './config.js';
import { HttpError, log } from './util.js';

let verifier;
async function getVerifier() {
  if (verifier) return verifier;
  const { getAuth } = await import('firebase-admin/auth');
  const { adminApp } = await import('./firebase.js');
  const auth = getAuth(adminApp());
  verifier = token => auth.verifyIdToken(token);
  return verifier;
}

/**
 * Authorization: Bearer <Firebase ID トークン> を検証して req.user を作る。
 * AUTH_MODE=dev のときだけ固定ユーザー（ローカル開発用。Cloud Run では起動時に拒否）。
 */
export async function requireUser(req, _res, next) {
  try {
    if (config.authMode === 'dev') {
      const uid = String(req.get('x-dev-user') || 'dev-user').replace(/[^\w-]/g, '').slice(0, 40) || 'dev-user';
      req.user = { uid, name: '開発ユーザー', email: 'dev@localhost', isAnonymous: false, picture: '' };
      return next();
    }
    const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
    if (!m) throw new HttpError(401, 'ログインが必要です', 'unauthenticated');
    let t;
    try {
      t = await (await getVerifier())(m[1]);
    } catch (e) {
      log.warn('verifyIdToken failed', { err: e.code || e.message });
      throw new HttpError(401, 'ログインの有効期限が切れました。再読み込みしてください', 'unauthenticated');
    }
    const isAnonymous = t.firebase?.sign_in_provider === 'anonymous';
    if (isAnonymous && !config.allowGuest) throw new HttpError(403, 'ゲスト利用は無効化されています', 'guest_disabled');
    if (!isAnonymous && config.allowedEmailDomains.length) {
      const email = String(t.email || '').toLowerCase();
      const ok = t.email_verified !== false && config.allowedEmailDomains.some(d => email.endsWith('@' + d.toLowerCase()) || email.endsWith('.' + d.toLowerCase()));
      if (!ok) throw new HttpError(403, `このアプリは ${config.allowedEmailDomains.join(', ')} のアカウントのみ利用できます`, 'domain_not_allowed');
    }
    req.user = { uid: t.uid, name: t.name || '', email: t.email || '', isAnonymous, picture: t.picture || '' };
    next();
  } catch (e) {
    next(e);
  }
}
