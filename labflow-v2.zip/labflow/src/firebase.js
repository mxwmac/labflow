import { initializeApp, getApps, applicationDefault } from 'firebase-admin/app';
import { config } from './config.js';

// Cloud Run 上ではサービスアカウントの認証情報（ADC）が自動で使われる。
// ローカルでは `gcloud auth application-default login` 済みであれば同じコードで動く。
export function adminApp() {
  if (getApps().length) return getApps()[0];
  return initializeApp({
    credential: applicationDefault(),
    ...(config.projectId ? { projectId: config.projectId } : {}),
  });
}
