// 初回ログイン時・「サンプル入りに戻す」で投入するデモデータ。日付は今日からの相対で作る。
import { config } from './config.js';
import { addDays, newId, ymd } from './util.js';

export const DEFAULT_PHASES = ['先行研究サーベイ', 'データセット構築', '手法の実装', '評価実験', '執筆'];

export function defaultSettings(sample = true) {
  return {
    topic: sample ? '深層学習による細胞画像のセグメンテーション' : '',
    calId: '',
    model: config.defaultModel,
    theme: 'light',
    workStart: 10,
    workEnd: 18,
    minSlot: 60,
    demoCal: sample,
    includeMine: true,
  };
}

export function sampleData() {
  const today = ymd();
  const iso = d => new Date(d + 'T09:00:00+09:00').toISOString();
  const now = new Date().toISOString();
  const phases = [100, 85, 60, 25, 5].map((pct, i) => ({ name: DEFAULT_PHASES[i], pct }));

  // 5週間ぶんの進捗推移（毎週少しずつ伸び、直近2週は評価実験が停滞している想定）
  const curve = [
    [90, 55, 30, 0, 0],
    [95, 65, 40, 5, 0],
    [100, 75, 45, 10, 0],
    [100, 80, 55, 20, 0],
    [100, 85, 60, 25, 0],
    [100, 85, 60, 25, 5],
  ];
  const progress = curve.map((row, i) => {
    const date = addDays(today, -35 + i * 7);
    return { id: date, date, avg: Math.round(row.reduce((a, b) => a + b, 0) / row.length), phases: row.map((pct, j) => ({ name: DEFAULT_PHASES[j], pct })) };
  });

  const m1 = newId(), m2 = newId();
  const p = (text, severity, status = 'open', extra = {}) => ({ id: newId(), text, severity, status, uncertain: false, ...extra });
  const meetings = [
    {
      id: m1, date: addDays(today, -17), title: '手法の方向性と評価指標', createdAt: iso(addDays(today, -17)), updatedAt: iso(addDays(today, -17)),
      summary: 'U-Net ベースラインの再現結果を報告。Dice は論文値に近いが境界部の精度が低い。評価指標と前処理の見直しを指示された。',
      confidence: 'high', model: 'sample', files: [], reviewed: true,
      flow: [
        { step: 'ベースライン報告', detail: 'U-Net の再現実験で Dice 0.86 を確認。', uncertain: false },
        { step: '境界精度の議論', detail: '細胞の境界がつぶれる例が多く、指標だけでは見えないと指摘。', uncertain: false },
        { step: '次の方針', detail: '境界に敏感な指標の追加と、前処理の正規化の再検討で合意。', uncertain: false },
      ],
      points: [
        p('Dice だけでなく Boundary F1 など境界の指標も出すこと', 'high', 'done', { doneAt: iso(addDays(today, -9)) }),
        p('前処理の正規化（per-image / dataset 全体）を比較すること', 'high'),
        p('関連研究に Cellpose 系を追加しておくこと', 'low', 'done', { doneAt: iso(addDays(today, -12)) }),
      ],
      decisions: [{ text: '評価指標は Dice と Boundary F1 の2本立てにする', uncertain: false }],
      todos: [
        { id: newId(), text: 'Boundary F1 の実装と既存結果への適用', due: addDays(today, -10), uncertain: false, taskId: '' },
        { id: newId(), text: '正規化の比較実験の設計', due: '', uncertain: false, taskId: '' },
      ],
      unclear: [],
    },
    {
      id: m2, date: addDays(today, -3), title: 'アノテーション品質と中間発表', createdAt: iso(addDays(today, -3)), updatedAt: iso(addDays(today, -3)),
      summary: '境界指標の結果を報告。アノテーションの揺れが評価に影響している可能性を議論し、κ係数での定量化を求められた。中間発表の構成も相談した。',
      confidence: 'mid', model: 'sample', files: [{ name: 'sample-note.jpg', mime: 'image/jpeg' }], reviewed: false,
      flow: [
        { step: '境界指標の報告', detail: 'Boundary F1 は 0.71。Dice との差から境界部の誤りが主因と分かった。', uncertain: false },
        { step: 'アノテーションの揺れ', detail: 'アノテータ間で境界の引き方が違う例を確認。κ係数で定量化する方針。', uncertain: false },
        { step: '中間発表の構成', detail: '背景→課題→手法→暫定結果の順。暫定結果は □□ 図を中心に。', uncertain: true },
      ],
      points: [
        p('アノテーション揺れを κ 係数で定量評価すること', 'high'),
        p('中間発表では暫定結果を誤差範囲つきで示すこと', 'mid'),
        p('正規化の比較は 2 条件に絞ってよい', 'low', 'open', { uncertain: true }),
      ],
      decisions: [{ text: '中間発表は 15 分・スライド 12 枚以内', uncertain: false }],
      todos: [
        { id: newId(), text: 'κ係数を 2 名分だけ先に算出', due: addDays(today, 4), uncertain: false, taskId: '' },
        { id: newId(), text: '中間発表スライドの構成案を先生に送る', due: addDays(today, 7), uncertain: false, taskId: '' },
      ],
      unclear: [
        { id: newId(), reading: '暫定結果は □□ 図を中心に', guess: '暫定結果は 箱ひげ図 を中心に', where: '議論の流れ「中間発表の構成」', resolved: false },
        { id: newId(), reading: '正規化の比較は 2 条件に絞って▲', guess: '正規化の比較は 2 条件に絞ってよい', where: '指摘事項 3件目', resolved: false },
      ],
    },
  ];

  const t = (title, tag, due, priority, done = false, source = { type: 'manual' }, ago = 10) => ({
    id: newId(), title, tag, due, dueText: '', priority, done, source,
    createdAt: iso(addDays(today, -ago)), doneAt: done ? now : '',
  });
  const tasks = [
    t('前処理パイプラインの正規化方法を再検討', '実装', addDays(today, 2), 'high', false, { type: 'mtg', meetingId: m1 }, 16),
    t('ベースライン(U-Net)の再現実験ログを整理', '実験', '', 'mid', true, { type: 'manual' }, 20),
    t('中間発表スライド構成案', '発表', addDays(today, 7), 'mid', false, { type: 'mtg', meetingId: m2 }, 3),
    t('アノテーション揺れの定量評価（κ係数）', '実験', addDays(today, -1), 'high', false, { type: 'mtg', meetingId: m2 }, 3),
  ];

  return { settings: defaultSettings(true), phases, progress, meetings, tasks };
}

export function emptyData() {
  return {
    settings: defaultSettings(false),
    phases: DEFAULT_PHASES.map(name => ({ name, pct: 0 })),
    progress: [], meetings: [], tasks: [],
  };
}
