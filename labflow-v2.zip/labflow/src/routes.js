import express from 'express';
import { config } from './config.js';
import { requireUser } from './auth.js';
import { getStore } from './store/index.js';
import { generateJSON, generateText, isMock } from './ai.js';
import { NOTE_SCHEMA, notePrompt, ACT_SCHEMA, suggestPrompt, REPORT_KINDS, reportPrompt } from './prompts.js';
import { mockNote, ruleActions, templateReport, reportTitle } from './fallback.js';
import { sampleData, emptyData, DEFAULT_PHASES } from './sample.js';
import { HttpError, log, newId, ymd, addDays, isYmd, str, pick, clampInt, arr } from './util.js';

export const api = express.Router();
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const SEVS = ['high', 'mid', 'low'];
const now = () => new Date().toISOString();

/* ------------------------------------------------------------
 * 公開設定（ログイン前に読む。秘密情報は含めない）
 * ---------------------------------------------------------- */
api.get('/config', (_req, res) => {
  res.json({
    authMode: config.authMode,
    allowGuest: config.allowGuest,
    firebase: config.firebase,
    oauthClientId: config.oauthClientId,
    models: config.models,
    defaultModel: config.defaultModel,
    aiMode: config.aiMode,
    maxUploadMB: config.maxUploadMB,
    timeZone: config.timeZone,
  });
});

api.use(requireUser);

/* ------------------------------------------------------------
 * 整形ヘルパー
 * ---------------------------------------------------------- */
function cleanPhases(list) {
  const out = arr(list, 8).map(p => ({ name: str(p?.name, 24) || 'フェーズ', pct: clampInt(p?.pct, 0, 100, 0) }));
  if (!out.length) throw new HttpError(400, 'フェーズが空です');
  return out;
}
const avgOf = phases => Math.round(phases.reduce((a, p) => a + p.pct, 0) / phases.length);

function cleanTask(b, base = {}) {
  const t = { ...base };
  if ('title' in b) t.title = str(b.title, 200);
  if ('tag' in b) t.tag = str(b.tag, 20);
  if ('due' in b) t.due = isYmd(b.due) ? b.due : '';
  if ('dueText' in b) t.dueText = str(b.dueText, 30);
  if ('priority' in b) t.priority = pick(b.priority, SEVS, 'mid');
  if ('done' in b) {
    t.done = !!b.done;
    t.doneAt = t.done ? base.doneAt || now() : '';
  }
  if ('memo' in b) t.memo = str(b.memo, 2000);
  return t;
}

/** Gemini の出力やクライアントからの編集を、保存できる形に整える（既存の id・状態は引き継ぐ） */
function cleanNote(n, prev = {}) {
  const keep = (list, id) => (list || []).find(x => x.id === id);
  return {
    title: str(n.title, 80) || 'ミーティング',
    date: isYmd(n.date) ? n.date : prev.date || ymd(),
    summary: str(n.summary, 2000),
    confidence: pick(n.confidence, SEVS, prev.confidence || 'mid'),
    flow: arr(n.flow, 12).map(f => ({ step: str(f?.step, 80), detail: str(f?.detail, 600), uncertain: !!f?.uncertain })),
    points: arr(n.points, 30).map(p => {
      const id = str(p?.id, 40) || newId();
      const old = keep(prev.points, id) || {};
      const status = pick(p?.status, ['open', 'done'], old.status || 'open');
      return { id, text: str(p?.text, 600), severity: pick(p?.severity, SEVS, 'mid'), uncertain: !!p?.uncertain, status, doneAt: status === 'done' ? old.doneAt || now() : '' };
    }),
    decisions: arr(n.decisions, 20).map(d => (typeof d === 'string' ? { text: str(d, 400), uncertain: false } : { text: str(d?.text, 400), uncertain: !!d?.uncertain })),
    todos: arr(n.todos, 30).map(t => {
      const id = str(t?.id, 40) || newId();
      const old = keep(prev.todos, id) || {};
      return { id, text: str(t?.text, 400), due: str(t?.due, 30), uncertain: !!t?.uncertain, taskId: str(t?.taskId ?? old.taskId, 40) };
    }),
    unclear: arr(n.unclear, 40).map(u => ({ id: str(u?.id, 40) || newId(), reading: str(u?.reading, 300), guess: str(u?.guess, 300), where: str(u?.where, 120), resolved: !!u?.resolved })),
  };
}

async function quota(req) {
  const store = await getStore();
  const limit = req.user.isAnonymous ? config.guestDailyLimit : config.dailyLimit;
  const r = await store.incrUsage(req.user.uid, ymd(), limit);
  if (!r.ok) throw new HttpError(429, `本日の AI 利用上限（${limit}回）に達しました。明日またお試しください`, 'quota');
  return { used: r.count, limit };
}

async function seed(uid, data, profile) {
  const store = await getStore();
  await store.setUser(uid, { profile, settings: data.settings, phases: data.phases, actions: null, createdAt: now(), updatedAt: now() }, { merge: false });
  await Promise.all([
    ...data.tasks.map(({ id, ...t }) => store.put(uid, 'tasks', id, t)),
    ...data.meetings.map(({ id, ...m }) => store.put(uid, 'meetings', id, m)),
    ...data.progress.map(({ id, ...p }) => store.put(uid, 'progress', id, p)),
  ]);
}
const profileOf = u => ({ name: u.name, email: u.email, isAnonymous: u.isAnonymous, picture: u.picture });

/* ------------------------------------------------------------
 * 起動時にまとめて読む
 * ---------------------------------------------------------- */
api.get('/bootstrap', wrap(async (req, res) => {
  const store = await getStore();
  const { uid } = req.user;
  let doc = await store.getUser(uid);
  if (!doc) {
    await seed(uid, sampleData(), profileOf(req.user));
    doc = await store.getUser(uid);
    log.info('seeded new user', { uid, guest: req.user.isAnonymous });
  } else if (JSON.stringify(doc.profile) !== JSON.stringify(profileOf(req.user))) {
    await store.setUser(uid, { profile: profileOf(req.user) });
  }
  const [tasks, meetings, progress, used] = await Promise.all([
    store.list(uid, 'tasks', { orderBy: 'createdAt' }),
    store.list(uid, 'meetings', { orderBy: 'date', desc: true, limit: 60 }),
    store.list(uid, 'progress', { orderBy: 'date', desc: true, limit: 180 }),
    store.getUsage(uid, ymd()),
  ]);
  const settings = { ...emptyData().settings, ...(doc.settings || {}) };
  if (!config.models.includes(settings.model)) settings.model = config.defaultModel;
  res.json({
    user: { uid, ...profileOf(req.user) },
    settings,
    phases: doc.phases || emptyData().phases,
    actions: doc.actions || null,
    tasks, meetings, progress: progress.reverse(),
    usage: { used, limit: req.user.isAnonymous ? config.guestDailyLimit : config.dailyLimit },
    today: ymd(),
  });
}));

/* ------------------------------------------------------------
 * 設定・進捗
 * ---------------------------------------------------------- */
api.patch('/settings', wrap(async (req, res) => {
  const store = await getStore();
  const b = req.body || {};
  const doc = (await store.getUser(req.user.uid)) || {};
  const s = { ...emptyData().settings, ...(doc.settings || {}) };
  if ('topic' in b) s.topic = str(b.topic, 200);
  if ('calId' in b) s.calId = str(b.calId, 200);
  if ('model' in b) s.model = pick(b.model, config.models, config.defaultModel);
  if ('theme' in b) s.theme = pick(b.theme, ['light', 'dark'], 'light');
  if ('workStart' in b) s.workStart = clampInt(b.workStart, 0, 23, 10);
  if ('workEnd' in b) s.workEnd = clampInt(b.workEnd, 1, 24, 18);
  if (s.workEnd <= s.workStart) s.workEnd = Math.min(24, s.workStart + 1);
  if ('minSlot' in b) s.minSlot = clampInt(b.minSlot, 15, 240, 60);
  if ('demoCal' in b) s.demoCal = !!b.demoCal;
  if ('includeMine' in b) s.includeMine = !!b.includeMine;
  const patch = { settings: s, updatedAt: now() };
  // フェーズ名の変更（進捗率は順番で引き継ぐ）
  if (Array.isArray(b.phaseNames)) {
    const names = b.phaseNames.map(n => str(n, 24)).filter(Boolean).slice(0, 8);
    if (names.length) {
      const old = doc.phases || [];
      patch.phases = names.map((name, i) => ({ name, pct: old[i]?.pct ?? 0 }));
    }
  }
  await store.setUser(req.user.uid, patch);
  res.json({ settings: s, phases: patch.phases || doc.phases });
}));

api.put('/phases', wrap(async (req, res) => {
  const store = await getStore();
  const phases = cleanPhases(req.body?.phases);
  const date = ymd();
  await store.setUser(req.user.uid, { phases, updatedAt: now() });
  const snap = await store.put(req.user.uid, 'progress', date, { date, avg: avgOf(phases), phases });
  res.json({ phases, snapshot: snap });
}));

/* ------------------------------------------------------------
 * タスク
 * ---------------------------------------------------------- */
api.post('/tasks', wrap(async (req, res) => {
  const store = await getStore();
  const b = req.body || {};
  const t = cleanTask({ title: '', tag: '', due: '', dueText: '', priority: 'mid', done: false, ...b });
  if (!t.title) throw new HttpError(400, 'タスク名が空です');
  const src = b.source || {};
  t.source = { type: pick(src.type, ['manual', 'mtg', 'suggest', 'point'], 'manual'), meetingId: str(src.meetingId, 40), refId: str(src.refId, 40) };
  t.createdAt = now();
  const id = newId();
  const saved = await store.put(req.user.uid, 'tasks', id, t);
  // MTG の ToDo から作った場合は、ToDo 側に紐付けを記録して「追加済」と分かるようにする
  if (t.source.type === 'mtg' && t.source.meetingId && t.source.refId) {
    const m = await store.get(req.user.uid, 'meetings', t.source.meetingId);
    if (m) {
      const todos = (m.todos || []).map(x => (x.id === t.source.refId ? { ...x, taskId: id } : x));
      await store.patch(req.user.uid, 'meetings', m.id, { todos, updatedAt: now() });
    }
  }
  res.status(201).json(saved);
}));

api.patch('/tasks/:id', wrap(async (req, res) => {
  const store = await getStore();
  const cur = await store.get(req.user.uid, 'tasks', req.params.id);
  if (!cur) throw new HttpError(404, 'タスクが見つかりません');
  const { id, ...base } = cur;
  const next = cleanTask(req.body || {}, base);
  if ('title' in (req.body || {}) && !next.title) throw new HttpError(400, 'タスク名が空です');
  res.json(await store.put(req.user.uid, 'tasks', id, next));
}));

api.delete('/tasks/:id', wrap(async (req, res) => {
  const store = await getStore();
  await store.remove(req.user.uid, 'tasks', req.params.id);
  res.status(204).end();
}));

/* ------------------------------------------------------------
 * MTG メモの解析・編集
 * ---------------------------------------------------------- */
const MIMES = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf'];

api.post('/meetings/analyze', wrap(async (req, res) => {
  const files = arr(req.body?.files, 10);
  if (!files.length) throw new HttpError(400, '画像またはPDFを1つ以上追加してください');
  let bytes = 0;
  for (const f of files) {
    if (!MIMES.includes(f?.mime)) throw new HttpError(400, `対応していない形式です: ${str(f?.name, 60)}（JPEG/PNG/WebP/HEIC/PDF）`);
    if (typeof f.data !== 'string' || !f.data) throw new HttpError(400, 'ファイルの中身が空です');
    bytes += Math.floor((f.data.length * 3) / 4);
  }
  if (bytes > config.maxUploadMB * 1024 * 1024) throw new HttpError(413, `ファイルの合計が大きすぎます（上限 ${config.maxUploadMB}MB）`);

  const store = await getStore();
  const usage = await quota(req);
  const doc = (await store.getUser(req.user.uid)) || {};
  const settings = { ...emptyData().settings, ...(doc.settings || {}) };
  const model = pick(req.body?.model || settings.model, config.models, config.defaultModel);
  const today = ymd();

  const t0 = Date.now();
  const raw = isMock()
    ? mockNote({ fileCount: files.length, today })
    : await generateJSON({
        model,
        schema: NOTE_SCHEMA,
        parts: [
          { text: notePrompt({ topic: settings.topic, today, fileCount: files.length }) },
          ...files.map(f => ({ inlineData: { mimeType: f.mime, data: f.data } })),
        ],
      });
  log.info('analyze done', { uid: req.user.uid, files: files.length, bytes, model, ms: Date.now() - t0 });

  const hintDate = isYmd(req.body?.date) ? req.body.date : '';
  const note = cleanNote({ ...raw, date: hintDate || raw.date || today });
  // 画像・PDF そのものは保存しない（解析後に破棄）。ファイル名だけ記録する
  const meeting = {
    ...note, reviewed: !note.unclear.length, model: isMock() ? 'mock' : model,
    files: files.map(f => ({ name: str(f.name, 80), mime: f.mime })),
    createdAt: now(), updatedAt: now(),
  };
  const id = newId();
  res.status(201).json({ meeting: await store.put(req.user.uid, 'meetings', id, meeting), usage });
}));

api.put('/meetings/:id', wrap(async (req, res) => {
  const store = await getStore();
  const cur = await store.get(req.user.uid, 'meetings', req.params.id);
  if (!cur) throw new HttpError(404, 'MTGノートが見つかりません');
  const { id, ...prev } = cur;
  const b = req.body || {};
  const note = cleanNote({ ...prev, ...b }, prev);
  const next = { ...prev, ...note, reviewed: 'reviewed' in b ? !!b.reviewed : prev.reviewed, updatedAt: now() };
  res.json(await store.put(req.user.uid, 'meetings', id, next));
}));

/** 指摘1件の対応状況だけを切り替える（一覧から素早く操作するため） */
api.patch('/meetings/:id/points/:pid', wrap(async (req, res) => {
  const store = await getStore();
  const m = await store.get(req.user.uid, 'meetings', req.params.id);
  if (!m) throw new HttpError(404, 'MTGノートが見つかりません');
  const status = pick(req.body?.status, ['open', 'done'], 'open');
  let found = false;
  const points = (m.points || []).map(p => {
    if (p.id !== req.params.pid) return p;
    found = true;
    return { ...p, status, doneAt: status === 'done' ? now() : '' };
  });
  if (!found) throw new HttpError(404, '指摘が見つかりません');
  res.json(await store.patch(req.user.uid, 'meetings', m.id, { points, updatedAt: now() }));
}));

api.delete('/meetings/:id', wrap(async (req, res) => {
  const store = await getStore();
  await store.remove(req.user.uid, 'meetings', req.params.id);
  res.status(204).end();
}));

/* ------------------------------------------------------------
 * 次の一手・報告書のための状況まとめ（サーバー側のデータから作る）
 * ---------------------------------------------------------- */
async function buildContext(uid, { days = 14, freeSlots = [] } = {}) {
  const store = await getStore();
  const today = ymd();
  const from = addDays(today, -days);
  const [doc, tasks, meetings, progress] = await Promise.all([
    store.getUser(uid),
    store.list(uid, 'tasks', { orderBy: 'createdAt' }),
    store.list(uid, 'meetings', { orderBy: 'date', desc: true, limit: 30 }),
    store.list(uid, 'progress', { orderBy: 'date', desc: true, limit: 120 }),
  ]);
  const phases = doc?.phases || emptyData().phases;
  const snapAt = d => progress.find(p => p.date <= d); // progress は新しい順
  const s14 = snapAt(addDays(today, -14));
  const sFrom = snapAt(from);
  const pctIn = (snap, name, i) => snap?.phases?.find(p => p.name === name)?.pct ?? snap?.phases?.[i]?.pct ?? 0;
  const label = m => `${m.date} ${m.title}`;
  const jstFrom = new Date(from + 'T00:00:00+09:00').toISOString();
  return {
    today, from, days,
    topic: doc?.settings?.topic || '',
    phases: phases.map((p, i) => ({ name: p.name, pct: p.pct, pct14: s14 ? pctIn(s14, p.name, i) : p.pct, pctStart: sFrom ? pctIn(sFrom, p.name, i) : 0 })),
    openTasks: tasks.filter(t => !t.done).map(t => ({ title: t.title, due: t.due || t.dueText || '', overdue: !!(t.due && t.due < today), priority: t.priority || 'mid', tag: t.tag || '' })),
    doneTasks: tasks.filter(t => t.done && (t.doneAt || '') >= jstFrom).map(t => ({ title: t.title, doneAt: (t.doneAt || '').slice(0, 10) })),
    openPoints: meetings.flatMap(m => (m.points || []).filter(p => p.status !== 'done').map(p => ({ text: p.text, severity: p.severity, meeting: label(m) }))),
    resolvedPoints: meetings.flatMap(m => (m.points || []).filter(p => p.status === 'done' && (p.doneAt || '') >= jstFrom).map(p => ({ text: p.text, meeting: label(m) }))),
    meetingsInPeriod: meetings.filter(m => m.date >= from).map(m => ({ date: m.date, title: m.title, summary: m.summary, decisions: (m.decisions || []).map(d => d.text) })),
    latestMeeting: meetings[0] ? { date: meetings[0].date, title: meetings[0].title, summary: meetings[0].summary } : null,
    freeSlots: arr(freeSlots, 15).map(s => str(s, 60)).filter(Boolean),
    model: pick(doc?.settings?.model, config.models, config.defaultModel),
  };
}

api.post('/suggest', wrap(async (req, res) => {
  const store = await getStore();
  const ctx = await buildContext(req.user.uid, { freeSlots: req.body?.freeSlots });
  let actions, fallback = false, notice = '';
  let usage = null;
  if (isMock()) {
    actions = ruleActions(ctx);
    fallback = true;
  } else {
    usage = await quota(req);
    try {
      const { model, ...forAi } = ctx;
      actions = (await generateJSON({ model, schema: ACT_SCHEMA, parts: [{ text: suggestPrompt(forAi) }] })).actions;
    } catch (e) {
      actions = ruleActions(ctx);
      fallback = true;
      notice = e.message;
    }
  }
  actions = arr(actions, 5).map(a => ({
    id: newId(), title: str(a.title, 200), why: str(a.why, 500), when: str(a.when, 60), effort: str(a.effort, 40),
    priority: pick(a.priority, SEVS, 'mid'), kind: pick(a.kind, ['task', 'meeting', 'focus'], 'task'), slot: str(a.slot, 60),
  }));
  const saved = { items: actions, at: now(), fallback };
  await store.setUser(req.user.uid, { actions: saved });
  res.json({ actions: saved, notice, usage });
}));

/* ------------------------------------------------------------
 * 報告書（週報・ゼミ報告・相談メール）の下書き
 * ---------------------------------------------------------- */
api.post('/reports', wrap(async (req, res) => {
  const store = await getStore();
  const kind = pick(req.body?.kind, Object.keys(REPORT_KINDS), 'weekly');
  const days = clampInt(req.body?.days, 1, 90, 7);
  const ctx = await buildContext(req.user.uid, { days, freeSlots: req.body?.freeSlots });
  let markdown, fallback = false, notice = '', usage = null;
  if (isMock()) {
    markdown = templateReport(kind, ctx);
    fallback = true;
  } else {
    usage = await quota(req);
    try {
      const { model, ...forAi } = ctx;
      markdown = await generateText({ model, prompt: reportPrompt(kind, forAi) });
    } catch (e) {
      markdown = templateReport(kind, ctx);
      fallback = true;
      notice = e.message;
    }
  }
  const report = { kind, days, title: reportTitle(kind, ctx), markdown: str(markdown, 20000), fallback, createdAt: now() };
  const saved = await store.put(req.user.uid, 'reports', newId(), report);
  res.status(201).json({ report: saved, notice, usage });
}));

api.get('/reports', wrap(async (req, res) => {
  const store = await getStore();
  res.json(await store.list(req.user.uid, 'reports', { orderBy: 'createdAt', desc: true, limit: 10 }));
}));

api.delete('/reports/:id', wrap(async (req, res) => {
  const store = await getStore();
  await store.remove(req.user.uid, 'reports', req.params.id);
  res.status(204).end();
}));

/* ------------------------------------------------------------
 * 全データ削除（空にする / サンプルに戻す）
 * ---------------------------------------------------------- */
api.post('/reset', wrap(async (req, res) => {
  const store = await getStore();
  const mode = pick(req.body?.mode, ['empty', 'sample'], 'empty');
  // AI 利用回数はリセットで回避できないよう、今日の分だけ残す
  const used = await store.getUsage(req.user.uid, ymd());
  await store.wipe(req.user.uid);
  await seed(req.user.uid, mode === 'sample' ? sampleData() : emptyData(), profileOf(req.user));
  if (used) await store.put(req.user.uid, 'usage', ymd(), { count: used, updatedAt: now() });
  log.info('reset', { uid: req.user.uid, mode });
  res.json({ ok: true, mode });
}));

export { DEFAULT_PHASES };
