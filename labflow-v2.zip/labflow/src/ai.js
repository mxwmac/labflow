import { GoogleGenAI } from '@google/genai';
import { config } from './config.js';
import { HttpError, log } from './util.js';

let client;
function ai() {
  if (client) return client;
  const httpOptions = { timeout: 150_000 };
  if (config.aiMode === 'vertex') {
    // Vertex AI（Gemini Enterprise Agent Platform）。Cloud Run のサービスアカウントで認証するため API キー不要
    client = new GoogleGenAI({ enterprise: true, project: config.projectId || undefined, location: config.geminiLocation, httpOptions });
  } else if (config.aiMode === 'apikey') {
    if (!config.geminiApiKey) throw new HttpError(500, 'GEMINI_API_KEY が設定されていません', 'ai_config');
    client = new GoogleGenAI({ apiKey: config.geminiApiKey, httpOptions });
  } else {
    throw new Error('mock mode has no client');
  }
  return client;
}

export const isMock = () => config.aiMode === 'mock';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const retryable = e => [429, 500, 503, 504].includes(e?.status) || /RESOURCE_EXHAUSTED|UNAVAILABLE|DEADLINE/i.test(e?.message || '');

async function call(fn, label) {
  let lastErr;
  for (let i = 0; i < 2; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      log.warn('gemini call failed', { label, attempt: i + 1, status: e?.status, err: String(e?.message || e).slice(0, 300) });
      if (e instanceof SyntaxError || retryable(e)) {
        await sleep(800 * (i + 1));
        continue;
      }
      break;
    }
  }
  const status = lastErr?.status;
  const msg =
    status === 404 ? 'モデルが見つかりません。設定のモデル名・リージョン（GEMINI_LOCATION）を確認してください'
    : status === 403 ? 'Gemini を呼び出す権限がありません（サービスアカウントに Vertex AI ユーザー権限が必要です）'
    : status === 429 ? 'Gemini の利用上限に達しました。少し待ってから再試行してください'
    : lastErr instanceof SyntaxError ? 'Gemini の応答を解釈できませんでした。もう一度お試しください'
    : 'Gemini の呼び出しに失敗しました';
  throw new HttpError(502, msg, 'ai_failed');
}

/** 構造化 JSON を返させる */
export async function generateJSON({ model, system, parts, schema }) {
  return call(async () => {
    const res = await ai().models.generateContent({
      model,
      contents: [{ role: 'user', parts }],
      config: {
        ...(system ? { systemInstruction: system } : {}),
        responseMimeType: 'application/json',
        responseJsonSchema: schema,
      },
    });
    const text = res.text || '';
    return JSON.parse(text);
  }, 'json');
}

/** Markdown などのテキストを返させる */
export async function generateText({ model, system, prompt }) {
  return call(async () => {
    const res = await ai().models.generateContent({
      model,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: system ? { systemInstruction: system } : {},
    });
    const text = (res.text || '').trim();
    if (!text) throw new SyntaxError('empty');
    return text.replace(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```\s*$/i, '$1');
  }, 'text');
}
