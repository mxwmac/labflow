// =============================================================
// Gemini へのプロンプトと構造化出力スキーマ（JSON Schema）
// =============================================================

export const NOTE_SCHEMA = {
  type: 'object',
  properties: {
    title: { type: 'string', description: 'このミーティングの短いタイトル（20文字程度）' },
    date: { type: 'string', description: 'メモから読み取れる日付を YYYY-MM-DD で。読み取れなければ空文字' },
    summary: { type: 'string', description: '3行程度の要約' },
    confidence: { type: 'string', enum: ['high', 'mid', 'low'], description: 'メモ全体の読み取りの確からしさ' },
    flow: {
      type: 'array', description: '議論の流れを時系列で3〜6ステップ',
      items: {
        type: 'object',
        properties: {
          step: { type: 'string', description: '短い見出し' },
          detail: { type: 'string', description: '1〜2文の説明' },
          uncertain: { type: 'boolean', description: '判読に自信がない語句を含むなら true' },
        },
        required: ['step', 'detail', 'uncertain'],
      },
    },
    points: {
      type: 'array', description: '指導教員からの指摘事項・宿題',
      items: {
        type: 'object',
        properties: {
          text: { type: 'string' },
          severity: { type: 'string', enum: ['high', 'mid', 'low'], description: '研究の進行への影響度' },
          uncertain: { type: 'boolean' },
        },
        required: ['text', 'severity', 'uncertain'],
      },
    },
    decisions: {
      type: 'array', description: 'その場で決まったこと',
      items: { type: 'object', properties: { text: { type: 'string' }, uncertain: { type: 'boolean' } }, required: ['text', 'uncertain'] },
    },
    todos: {
      type: 'array', description: '学生が次にやるべき具体作業',
      items: {
        type: 'object',
        properties: {
          text: { type: 'string' },
          due: { type: 'string', description: '期限。日付が分かれば YYYY-MM-DD、それ以外は記載どおり。無ければ空文字' },
          uncertain: { type: 'boolean' },
        },
        required: ['text', 'due', 'uncertain'],
      },
    },
    unclear: {
      type: 'array', description: '判読できなかった・自信がない語句の一覧',
      items: {
        type: 'object',
        properties: {
          reading: { type: 'string', description: '紙面に見えたままの文字列（判読不能部分は □ で表す）' },
          guess: { type: 'string', description: '最も可能性が高い解釈。推測できなければ空文字' },
          where: { type: 'string', description: 'どの項目（指摘/ToDo/流れ など）のどの文に出てくるか' },
        },
        required: ['reading', 'guess', 'where'],
      },
    },
  },
  required: ['title', 'date', 'summary', 'confidence', 'flow', 'points', 'decisions', 'todos', 'unclear'],
};

export function notePrompt({ topic, today, fileCount }) {
  return `あなたは大学研究室の学生の議事録アシスタントです。
添付の ${fileCount} 件のファイル（写真またはPDF）は、指導教員とのミーティング中に学生が手書きしたメモです（日本語、走り書き、略語・矢印・図を含む）。
研究テーマ: ${topic || '（未設定）'}
今日の日付: ${today}

次を日本語で抽出してください。
- flow: 議論がどの順で進んだかを3〜6ステップに再構成。
- points: 先生から受けた指摘・宿題。severity は研究の進行への影響度（high=放置すると研究が止まる / mid=次回までに対応 / low=参考）。
- decisions: その場で決まったこと。
- todos: 学生が次にやるべき具体作業。「来週」「次回まで」などは今日の日付から YYYY-MM-DD に換算してよい。
- unclear: 判読に自信がない語句をすべて列挙。

厳守:
- 読み取れない箇所を推測で埋めて断定しないこと。自信がない語句を含む項目は uncertain=true にし、unclear にも載せる。
- 紙面に無い内容を創作しないこと。
- 専門用語は研究テーマに照らして自然な表記に整えてよいが、その場合も迷いがあれば unclear に載せる。`;
}

export const ACT_SCHEMA = {
  type: 'object',
  properties: {
    actions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string', description: '動詞で終わる具体的な次の行動' },
          why: { type: 'string', description: 'なぜ今それなのか（1〜2文）。根拠になった指摘やタスクに触れる' },
          when: { type: 'string', description: 'いつやるか' },
          effort: { type: 'string', description: '所要時間の目安' },
          priority: { type: 'string', enum: ['high', 'mid', 'low'] },
          kind: { type: 'string', enum: ['task', 'meeting', 'focus'], description: 'meeting=先生への相談アポ, focus=まとまった作業時間の確保, task=それ以外' },
          slot: { type: 'string', description: 'kind=meeting の場合、提示された先生の空き時間の中から1つをそのまま書く。それ以外は空文字' },
        },
        required: ['title', 'why', 'when', 'effort', 'priority', 'kind', 'slot'],
      },
    },
  },
  required: ['actions'],
};

export function suggestPrompt(ctx) {
  return `あなたは研究の進め方に詳しいメンターです。以下の学生の状況から、今日〜今週に取るべき行動を3件、優先度順に提案してください。
- 抽象論ではなく、すぐ着手できる粒度にすること
- 期限切れ・期限間近のタスク、未対応の high 指摘を最優先にすること
- 先生の空き時間がある場合は、相談アポ（kind=meeting）を1件含め、slot には空き時間の文字列をそのまま書くこと
- 進捗が2週間ほとんど動いていないフェーズがあれば、そのボトルネックに触れること

状況(JSON):
${JSON.stringify(ctx, null, 1)}`;
}

export const REPORT_KINDS = {
  weekly: '週報',
  seminar: 'ゼミ進捗報告',
  email: '指導教員への相談依頼メール',
};

export function reportPrompt(kind, ctx) {
  const common = `以下は研究室の学生の活動記録(JSON)です。記録にない成果を創作しないでください。数値は記録の値をそのまま使ってください。
出力は Markdown のみ（前置き・コードブロック不要）。

記録:
${JSON.stringify(ctx, null, 1)}`;
  if (kind === 'email') {
    return `学生から指導教員へ送る、相談アポイントのお願いメールの下書きを書いてください。
- 件名を1行目に「件名: 」で始めて書く
- 丁寧だが簡潔に（本文400字程度）。相談したい論点は未対応の指摘から2〜3点、箇条書き
- 候補日時は「先生の空き時間」から2〜3個を提示（無ければ「ご都合のよい日時」を伺う）
- 署名は「（氏名）」のままにする
${common}`;
  }
  if (kind === 'seminar') {
    return `ゼミで発表する進捗報告（A4 1枚程度）を書いてください。
構成: ## 研究テーマ / ## 前回からの進捗（フェーズ別の進捗率の変化を表で）/ ## 前回の指摘への対応状況 / ## 課題と相談したいこと / ## 次回までの予定
${common}`;
  }
  return `指定期間の週報を書いてください。
構成: ## 今週やったこと / ## 進捗率（フェーズ別に前→今）/ ## 指摘への対応 / ## 困っていること / ## 来週やること
箇条書き中心で簡潔に。
${common}`;
}
