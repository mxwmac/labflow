import { randomUUID } from 'node:crypto';
import { config } from './config.js';

// Cloud Logging が severity を解釈できる JSON 1行ログ
export const log = {
  info: (message, extra = {}) => console.log(JSON.stringify({ severity: 'INFO', message, ...extra })),
  warn: (message, extra = {}) => console.warn(JSON.stringify({ severity: 'WARNING', message, ...extra })),
  error: (message, extra = {}) => console.error(JSON.stringify({ severity: 'ERROR', message, ...extra })),
};

export const newId = () => randomUUID().replace(/-/g, '').slice(0, 20);

/** アプリのタイムゾーン（既定: Asia/Tokyo）での YYYY-MM-DD */
export function ymd(d = new Date()) {
  return new Intl.DateTimeFormat('sv-SE', { timeZone: config.timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}
export function addDays(ymdStr, n) {
  const d = new Date(ymdStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export const isYmd = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);

// ---- 入力の整形（クライアントから来た値は必ずここを通す） ----
export const str = (v, max = 500) => (typeof v === 'string' ? v.trim().slice(0, max) : v == null ? '' : String(v).slice(0, max));
export const pick = (v, allowed, d) => (allowed.includes(v) ? v : d);
export const clampInt = (v, lo, hi, d) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d;
};
export const arr = (v, max = 50) => (Array.isArray(v) ? v.slice(0, max) : []);

export class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
