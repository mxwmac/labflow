// Firestore 保存。サーバー（Cloud Run のサービスアカウント）だけが読み書きし、
// ブラウザからの直接アクセスは firestore.rules で全面禁止している。
//
// データ構造:
//   users/{uid}                     設定・フェーズ進捗・直近の提案
//   users/{uid}/tasks/{id}          タスク
//   users/{uid}/meetings/{id}       MTGノート（解析結果・指摘の対応状況）
//   users/{uid}/progress/{YYYY-MM-DD} 日ごとの進捗スナップショット
//   users/{uid}/reports/{id}        生成した報告書
//   users/{uid}/usage/{YYYY-MM-DD}  AI 呼び出し回数
import { getFirestore } from 'firebase-admin/firestore';
import { adminApp } from '../firebase.js';
import { config } from '../config.js';

export function createFirestoreStore() {
  const db = config.firestoreDatabase === '(default)' ? getFirestore(adminApp()) : getFirestore(adminApp(), config.firestoreDatabase);
  db.settings({ ignoreUndefinedProperties: true });
  const userRef = uid => db.collection('users').doc(uid);
  const col = (uid, name) => userRef(uid).collection(name);

  return {
    kind: 'firestore',
    async getUser(uid) {
      const s = await userRef(uid).get();
      return s.exists ? s.data() : null;
    },
    async setUser(uid, data, { merge = true } = {}) {
      await userRef(uid).set(data, { merge });
    },
    async list(uid, name, { orderBy = 'createdAt', desc = false, limit = 500 } = {}) {
      const q = await col(uid, name).orderBy(orderBy, desc ? 'desc' : 'asc').limit(limit).get();
      return q.docs.map(d => ({ ...d.data(), id: d.id }));
    },
    async get(uid, name, id) {
      const s = await col(uid, name).doc(id).get();
      return s.exists ? { ...s.data(), id: s.id } : null;
    },
    async put(uid, name, id, data) {
      await col(uid, name).doc(id).set(data);
      return { ...data, id };
    },
    async patch(uid, name, id, data) {
      const ref = col(uid, name).doc(id);
      try {
        await ref.update(data);
      } catch (e) {
        if (e.code === 5) return null; // NOT_FOUND
        throw e;
      }
      const s = await ref.get();
      return { ...s.data(), id: s.id };
    },
    async remove(uid, name, id) {
      await col(uid, name).doc(id).delete();
      return true;
    },
    async getUsage(uid, date) {
      const s = await col(uid, 'usage').doc(date).get();
      return s.exists ? s.data().count || 0 : 0;
    },
    async incrUsage(uid, date, limit) {
      const ref = col(uid, 'usage').doc(date);
      return db.runTransaction(async tx => {
        const s = await tx.get(ref);
        const count = s.exists ? s.data().count || 0 : 0;
        if (count >= limit) return { ok: false, count };
        tx.set(ref, { count: count + 1, updatedAt: new Date().toISOString() });
        return { ok: true, count: count + 1 };
      });
    },
    async wipe(uid) {
      await db.recursiveDelete(userRef(uid));
    },
  };
}
