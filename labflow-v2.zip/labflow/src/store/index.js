import { config } from '../config.js';
import { createMemoryStore } from './memory.js';

let store;
export async function getStore() {
  if (store) return store;
  if (config.store === 'memory') {
    store = createMemoryStore();
  } else {
    const { createFirestoreStore } = await import('./firestore.js');
    store = createFirestoreStore();
  }
  return store;
}
