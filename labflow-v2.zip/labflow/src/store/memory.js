// ローカル試用・テスト用のインメモリ保存。プロセスを止めると消える。
// Firestore 版（firestore.js）と同じインターフェースを持つ。
export function createMemoryStore() {
  const users = new Map(); // uid -> { doc, cols: Map<col, Map<id, data>> }
  const u = uid => {
    if (!users.has(uid)) users.set(uid, { doc: null, cols: new Map() });
    return users.get(uid);
  };
  const c = (uid, col) => {
    const x = u(uid);
    if (!x.cols.has(col)) x.cols.set(col, new Map());
    return x.cols.get(col);
  };
  const clone = v => (v == null ? v : structuredClone(v));

  return {
    kind: 'memory',
    async getUser(uid) { return clone(u(uid).doc); },
    async setUser(uid, data, { merge = true } = {}) {
      const x = u(uid);
      x.doc = merge ? { ...(x.doc || {}), ...clone(data) } : clone(data);
    },
    async list(uid, col, { orderBy = 'createdAt', desc = false, limit = 500 } = {}) {
      const rows = [...c(uid, col).entries()].map(([id, d]) => ({ ...clone(d), id }));
      rows.sort((a, b) => (String(a[orderBy] ?? '') < String(b[orderBy] ?? '') ? -1 : String(a[orderBy] ?? '') > String(b[orderBy] ?? '') ? 1 : 0));
      if (desc) rows.reverse();
      return rows.slice(0, limit);
    },
    async get(uid, col, id) {
      const d = c(uid, col).get(id);
      return d ? { ...clone(d), id } : null;
    },
    async put(uid, col, id, data) { c(uid, col).set(id, clone(data)); return { ...clone(data), id }; },
    async patch(uid, col, id, data) {
      const m = c(uid, col);
      if (!m.has(id)) return null;
      const next = { ...m.get(id), ...clone(data) };
      m.set(id, next);
      return { ...clone(next), id };
    },
    async remove(uid, col, id) { return c(uid, col).delete(id); },
    async getUsage(uid, date) { return c(uid, 'usage').get(date)?.count || 0; },
    async incrUsage(uid, date, limit) {
      const m = c(uid, 'usage');
      const count = m.get(date)?.count || 0;
      if (count >= limit) return { ok: false, count };
      m.set(date, { count: count + 1 });
      return { ok: true, count: count + 1 };
    },
    async wipe(uid) { users.delete(uid); },
  };
}
