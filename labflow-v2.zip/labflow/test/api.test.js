// API の結合テスト（メモリ保存・AIモック・開発用認証で動かす）
//   npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

process.env.AUTH_MODE = 'dev';
process.env.STORE = 'memory';
process.env.AI_MODE = 'mock';
delete process.env.K_SERVICE;

let server, base;
before(async () => {
  const { app } = await import('../server.js');
  await new Promise(r => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}/api`;
});
after(() => server.close());

const call = async (method, path, body, user = 't1') => {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', 'x-dev-user': user },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  return { status: r.status, body: text ? JSON.parse(text) : null };
};

test('config は公開情報だけを返す', async () => {
  const r = await call('GET', '/config');
  assert.equal(r.status, 200);
  assert.ok(Array.isArray(r.body.models));
  assert.equal(r.body.geminiApiKey, undefined);
});

test('初回 bootstrap でサンプルが入る', async () => {
  const r = await call('GET', '/bootstrap');
  assert.equal(r.status, 200);
  assert.equal(r.body.tasks.length, 4);
  assert.equal(r.body.meetings.length, 2);
  assert.ok(r.body.progress.length >= 5);
});

test('タスクの追加・更新・削除', async () => {
  const c = await call('POST', '/tasks', { title: '  テスト  ', due: '2026-12-01', priority: 'high' });
  assert.equal(c.status, 201);
  assert.equal(c.body.title, 'テスト');
  const u = await call('PATCH', `/tasks/${c.body.id}`, { done: true });
  assert.equal(u.body.done, true);
  assert.ok(u.body.doneAt);
  const bad = await call('POST', '/tasks', { title: '' });
  assert.equal(bad.status, 400);
  const d = await call('DELETE', `/tasks/${c.body.id}`);
  assert.equal(d.status, 204);
});

test('進捗の保存で当日のスナップショットが残る', async () => {
  const r = await call('PUT', '/phases', { phases: [{ name: 'A', pct: 40 }, { name: 'B', pct: 103 }] });
  assert.equal(r.status, 200);
  assert.equal(r.body.phases[1].pct, 100);
  assert.equal(r.body.snapshot.avg, 70);
});

test('メモ解析（モック）→ 指摘の対応状況 → ToDo のタスク化', async () => {
  const a = await call('POST', '/meetings/analyze', { files: [{ name: 'a.jpg', mime: 'image/jpeg', data: 'AAAA' }] });
  assert.equal(a.status, 201);
  const m = a.body.meeting;
  assert.ok(m.unclear.length > 0);
  assert.equal(m.reviewed, false);
  const p = await call('PATCH', `/meetings/${m.id}/points/${m.points[0].id}`, { status: 'done' });
  assert.equal(p.body.points[0].status, 'done');
  const t = await call('POST', '/tasks', { title: m.todos[0].text, source: { type: 'mtg', meetingId: m.id, refId: m.todos[0].id } });
  const b = await call('GET', '/bootstrap');
  const saved = b.body.meetings.find(x => x.id === m.id);
  assert.equal(saved.todos[0].taskId, t.body.id);
});

test('不正な形式のファイルは拒否', async () => {
  const r = await call('POST', '/meetings/analyze', { files: [{ name: 'x.exe', mime: 'application/x-msdownload', data: 'AAAA' }] });
  assert.equal(r.status, 400);
});

test('次の一手と報告書（モック）', async () => {
  const s = await call('POST', '/suggest', { freeSlots: ['11/12(木) 13:00〜15:00'] });
  assert.equal(s.status, 200);
  assert.ok(s.body.actions.items.length >= 1);
  for (const kind of ['weekly', 'seminar', 'email']) {
    const r = await call('POST', '/reports', { kind, days: 14 });
    assert.equal(r.status, 201);
    assert.ok(r.body.report.markdown.length > 20);
  }
  const list = await call('GET', '/reports');
  assert.equal(list.body.length, 3);
});

test('ユーザー間でデータが分離される', async () => {
  await call('POST', '/tasks', { title: 'u2 only' }, 'u2');
  const a = await call('GET', '/bootstrap', undefined, 't1');
  assert.ok(!a.body.tasks.some(t => t.title === 'u2 only'));
});

test('リセット（空にする）でも AI 利用回数は残る', async () => {
  const before = (await call('GET', '/bootstrap')).body.usage.used;
  const r = await call('POST', '/reset', { mode: 'empty' });
  assert.equal(r.status, 200);
  const b = await call('GET', '/bootstrap');
  assert.equal(b.body.tasks.length, 0);
  assert.equal(b.body.usage.used, before);
});

test('存在しない API は 404 JSON', async () => {
  const r = await call('GET', '/nope');
  assert.equal(r.status, 404);
  assert.ok(r.body.error.message);
});
