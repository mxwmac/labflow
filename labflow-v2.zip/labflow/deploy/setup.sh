#!/usr/bin/env bash
# =============================================================
# LabFlow — Google Cloud プロジェクトの初期設定（最初に1回だけ）
#   使い方:  PROJECT_ID=my-project ./deploy/setup.sh
#   何度実行しても安全（作成済みのものはスキップ）
# =============================================================
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-northeast1}"
SERVICE="${SERVICE:-labflow}"
SA_NAME="${SA_NAME:-labflow-run}"

if [[ -z "${PROJECT_ID}" ]]; then
  echo "PROJECT_ID を指定してください（例: PROJECT_ID=my-project ./deploy/setup.sh）" >&2
  exit 1
fi
SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
step() { printf '\n\033[1;34m▶ %s\033[0m\n' "$*"; }

step "プロジェクト: ${PROJECT_ID} / リージョン: ${REGION}"
gcloud config set project "${PROJECT_ID}" >/dev/null
PROJECT_NUMBER="$(gcloud projects describe "${PROJECT_ID}" --format='value(projectNumber)')"

step "API を有効化（数分かかることがあります）"
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  aiplatform.googleapis.com \
  firestore.googleapis.com \
  calendar-json.googleapis.com \
  firebase.googleapis.com \
  identitytoolkit.googleapis.com \
  iam.googleapis.com

step "Firestore（ネイティブモード）を作成"
if gcloud firestore databases describe --database='(default)' >/dev/null 2>&1; then
  echo "  既に存在します"
else
  gcloud firestore databases create --database='(default)' --location="${REGION}" --type=firestore-native
fi

step "Cloud Run 用サービスアカウントを作成: ${SA_EMAIL}"
if gcloud iam service-accounts describe "${SA_EMAIL}" >/dev/null 2>&1; then
  echo "  既に存在します"
else
  gcloud iam service-accounts create "${SA_NAME}" --display-name="LabFlow Cloud Run"
  sleep 5 # 作成直後は IAM に反映されるまで少し待つ
fi

step "サービスアカウントに最小限の権限を付与"
#   Vertex AI ユーザー（Gemini 呼び出し） / Cloud Datastore ユーザー（Firestore 読み書き） / ログ書き込み
for ROLE in roles/aiplatform.user roles/datastore.user roles/logging.logWriter; do
  gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
    --member="serviceAccount:${SA_EMAIL}" --role="${ROLE}" --condition=None --quiet >/dev/null
  echo "  ${ROLE}"
done

step "ソースからのデプロイ（Cloud Build）に使うアカウントへ権限を付与"
#   gcloud run deploy --source は Compute Engine のデフォルト SA でビルドする
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
  --member="serviceAccount:${PROJECT_NUMBER}-compute@developer.gserviceaccount.com" \
  --role="roles/run.builder" --condition=None --quiet >/dev/null && echo "  roles/run.builder"

URL="https://${SERVICE}-${PROJECT_NUMBER}.${REGION}.run.app"
cat <<EOF

✅ 初期設定が終わりました。

デプロイ後の URL（予定）: ${URL}

次の作業（コンソールで行います。詳しくは README の手順 2〜4）:
  1. Firebase コンソールでこのプロジェクトに Firebase を追加し、ウェブアプリを登録
     → apiKey と appId を deploy/env.yaml に記入
  2. Authentication で「Google」と「匿名」を有効化し、
     承認済みドメインに ${SERVICE}-${PROJECT_NUMBER}.${REGION}.run.app を追加
  3. Google Auth Platform で Calendar のスコープを追加し、
     ウェブクライアントの「承認済みの JavaScript 生成元」に ${URL} を追加
     → クライアント ID を deploy/env.yaml に記入
  4. ./deploy/deploy.sh を実行
EOF
