#!/usr/bin/env bash
# =============================================================
# LabFlow — Cloud Run へデプロイ（ソースから Cloud Build でビルド）
#   使い方:  ./deploy/deploy.sh
#   事前に:  ./deploy/setup.sh を1回実行し、deploy/env.yaml を用意しておく
# =============================================================
set -euo pipefail
cd "$(dirname "$0")/.."

ENV_FILE="${ENV_FILE:-deploy/env.yaml}"
REGION="${REGION:-asia-northeast1}"
SERVICE="${SERVICE:-labflow}"
SA_NAME="${SA_NAME:-labflow-run}"

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "${ENV_FILE} がありません。cp deploy/env.example.yaml ${ENV_FILE} して値を埋めてください。" >&2
  exit 1
fi

# env.yaml の GOOGLE_CLOUD_PROJECT をデプロイ先にする（gcloud の既定プロジェクトと食い違う事故を防ぐ）
PROJECT_ID="$(sed -nE 's/^GOOGLE_CLOUD_PROJECT:[[:space:]]*"?([^"#[:space:]]+)"?.*/\1/p' "${ENV_FILE}")"
if [[ -z "${PROJECT_ID}" || "${PROJECT_ID}" == "your-project-id" ]]; then
  echo "${ENV_FILE} の GOOGLE_CLOUD_PROJECT を設定してください。" >&2
  exit 1
fi
for KEY in FIREBASE_API_KEY FIREBASE_APP_ID OAUTH_CLIENT_ID; do
  if grep -qE "^${KEY}:[[:space:]]*\"?(AIza\.\.\.|1:123456789012:web:abcdef|123456789012-xxxx[^\"]*|)\"?[[:space:]]*(#.*)?$" "${ENV_FILE}"; then
    echo "⚠ ${KEY} が未設定のようです（ログインやカレンダー連携が動きません）。続行します…" >&2
  fi
done

SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
echo "▶ ${SERVICE} を ${PROJECT_ID} / ${REGION} にデプロイします"

gcloud run deploy "${SERVICE}" \
  --project="${PROJECT_ID}" \
  --region="${REGION}" \
  --source=. \
  --service-account="${SA_EMAIL}" \
  --env-vars-file="${ENV_FILE}" \
  --allow-unauthenticated \
  --cpu=1 \
  --memory=512Mi \
  --concurrency=40 \
  --min-instances=0 \
  --max-instances=3 \
  --timeout=300 \
  --cpu-boost \
  --quiet

URL="$(gcloud run services describe "${SERVICE}" --project="${PROJECT_ID}" --region="${REGION}" --format='value(status.url)')"
echo
echo "✅ デプロイ完了: ${URL}"
echo "   ヘルスチェック: $(curl -fsS "${URL}/healthz" 2>/dev/null || echo '応答なし（数十秒後に再確認してください）')"
echo
echo "初回だけ確認してください:"
echo "  ・Firebase Authentication の承認済みドメインに ${URL#https://} がある"
echo "  ・OAuth クライアントの承認済みの JavaScript 生成元に ${URL} がある"
